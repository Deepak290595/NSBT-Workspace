package question5;

class PracticeHead extends Employee{
	String practiceName="Deepak";
	int noOfCustomer=2;
	void modify(){
		this.noOfCustomer=5;
		this.phoneNumber=7827718534L;
		System.out.println("Updated details:" +this.noOfCustomer+" "+this.phoneNumber);
	}
	void display(){
		System.out.println(this.empId+" "+this.practiceName+" "+this.noOfCustomer+" " +this.phoneNumber);
	}
}
public class Employee {
	int empId=121;
	String name;
	int projectId;
	long phoneNumber=8964999700L;
	
	
	public static void main(String[] args) {
		PracticeHead p = new PracticeHead();
		p.display();
		p.modify();
	}

}
