package question3;

class Manager extends Employee{
	String department;
	Manager(){
		this.department="NSBT";
	}
	public String toString(){
		return this.name+this.department+this.salary ;
	}
}
class Executive extends Manager{
	public String toString(){
		return "Executive "+this.name+" "+this.department+" "+this.salary;
		
	}
}
public class Employee {
	String name;
	double salary;
	Employee(){
		this.name="Deepak";
		this.salary=350000;
	}
	public static void main(String[] args) {
		Employee e = new Executive();
		System.out.println(e.toString());
	}
}
