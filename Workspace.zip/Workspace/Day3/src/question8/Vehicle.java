package question8;

class Truck extends Vehicle{
	int loadingCapacity = 100;
	void modify(){
		this.loadingCapacity=200;
		this.color="White";
	}
	void display(){
		System.out.println("Details: "+this.loadingCapacity+ " "+this.color); 
	}
}
public class Vehicle {
	int vehicleNo=101;
	String model="Eco Sport";
	String manufacturer ="ford";
	String color="black";
	public static void main(String[] args) {
		Truck e = new Truck();
		e.display();
		e.modify();
		e.display();
	}

}