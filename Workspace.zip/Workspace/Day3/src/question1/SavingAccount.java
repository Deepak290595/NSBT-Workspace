package question1;

public class SavingAccount extends Account {

	double minBalance = 1000.00, withdraw_limit = 100000.00;
	Account account = new Account();

	public double withdraw(double withdraw_amount) {
		if ((withdraw_amount > withdraw_limit)) {
			System.out.println("Overflow");
			return 0;
		} else {
			if ((account.getAccountBalance() - withdraw_amount) < minBalance) {
				System.out.println("underflow !!");
				return 0;
			} else
				return account.getAccountBalance() - withdraw_amount;
		}
	}

	public double compoundInterest(double principalAmount) {
		double interest = 0.05;
		return principalAmount * interest + principalAmount;
	}

}
