package question1;

import java.util.Scanner;

public class Banking {

	public static void main(String[] args) {

		// String customerName,accountType;
		// double accountNumber,
		double accountBalance = 10000.00;
		Scanner scan = new Scanner(System.in);
		SavingAccount saving = new SavingAccount();
		CurrentAccount current = new CurrentAccount();

		System.out.println("Which type of Account :");
		System.out.println(" 1.Savings \n 2.Current\n");
		do{
		int choice1 = scan.nextInt();
		switch (choice1) {
		case 1:
			System.out.println("\nPress[1] for Compound Interest" +"\n"+ "Press[2] for withdrawl facility \n");
			int input = scan.nextInt();
			if (input == 1) {
				System.out.println("Compount Amount is="+ saving.compoundInterest(accountBalance));
				break;
			}
			if (input == 2) {
				System.out.println("Enter the Amount!");
				input = scan.nextInt();
				current.withdraw(input);
				System.out.println("Amount has been withdraw!!");
				break;
			} else {
				System.out.println("Wrong input...");
				break;
			}
		case 2:
			current.penalty();

			System.out.println("do you want to issue cheque ? (1 for yes and 2 for no)");
			int choice3 = scan.nextInt();
			if (choice3 == 1) {
				System.out.println(current.chequeAmount(5000));
				break;
			} else {
				System.out.println("Thank you for visiting !!");
				break;
			}
		default:
			System.out.println("wrong choice entered..press 0 for exit");
			int in = scan.nextInt();
			System.exit(in);
		}
		
	}while(true);
		}
	
}