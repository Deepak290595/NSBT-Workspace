package question2;

class Student extends Person{
	String major="Computer Science";
	void displayMajor(){
		System.out.println(this.name+" has "+major);
	}
}
class Instructor extends Person{
	double salary=2700;
	void annSalary(){
		System.out.println(this.name+" has annual salary "+ 12*this.salary);
	}
}
public class Person {
	String name="Deepak";
	int yearofbirth=1995;
	public static void main(String[] args) {
		Instructor i = new Instructor();
		Student s = new Student();
		i.annSalary();
		s.displayMajor();
	}

}
