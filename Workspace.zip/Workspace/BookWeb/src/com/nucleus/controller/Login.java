package com.nucleus.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }
    private void login(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    	PrintWriter out = response.getWriter();
		String uName = request.getParameter("uname");
		String psw = request.getParameter("psw");
		//String rem = request.getParameter("remember");
		//out.print(rem);
		/*if(rem=="on"){
			Cookie cookie = new Cookie("user", uName);
		}*/
		if(psw.equals("deepak@29")){
		HttpSession session = request.getSession();
		session.setAttribute("uname",uName);
		out.println("Welcome "+uName);
		response.setContentType("text/html");
	    RequestDispatcher rd=request.getRequestDispatcher("/HomePage.html");  
	    rd.include(request, response);
		}
		else{
			out.println("User Id password mismatch");
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		login(request,response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		login(request,response);
	}

}
