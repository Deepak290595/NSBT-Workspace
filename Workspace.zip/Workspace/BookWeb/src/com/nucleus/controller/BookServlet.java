package com.nucleus.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nucleus.model.dao.BookDAO;
import com.nucleus.model.dao.BookDAOFactory;
import com.nucleus.model.domain.Book;

/**
 * Servlet implementation class BookServlet
 */
@WebServlet("/BookServlet")
public class BookServlet extends HttpServlet {
	BookDAO dao = BookDAOFactory.getObject("rdbms");
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BookServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @throws IOException 
	 * @throws ServletException 
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    public void save(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
    	PrintWriter out = response.getWriter();
    	String bPublisher="";
    	int bID = Integer.parseInt(request.getParameter("bookid"));
    	String bName = request.getParameter("bookname");
    	String bAuthor = request.getParameter("bookauthor");
    	String bGenre = request.getParameter("genre");
    	int bPrice = Integer.parseInt(request.getParameter("price"));
    	String [] publArray = request.getParameterValues("Publishers");
    	String bDiscription = request.getParameter("description");
    	String bPublishingDate = request.getParameter("date");
    	for(String s : publArray){
    		bPublisher = bPublisher+s+",";
    	}
    	bPublisher = bPublisher.substring(0,bPublisher.length()-1);
    	Book book =new Book(bID, bName, bAuthor, bGenre, bPrice, bPublisher, bPublishingDate, bDiscription);
    	dao.save(book);
    	//out.println(bPublishingDate);
    	//out.print("Book saved");
        out.print("Book Successfully Saved"); 
        response.setContentType("text/html");
        RequestDispatcher rd=request.getRequestDispatcher("/HomePage.html");  
        rd.include(request, response);  
    }
    
    private void view(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    	PrintWriter out = response.getWriter();
    	int bookID = Integer.parseInt(request.getParameter("bookid"));
    	Book book = dao.view(bookID);
    	if(book==null){
    		response.setContentType("text/html");
			out.println("Book Does not Exist");
	        RequestDispatcher rd=request.getRequestDispatcher("/HomePage.html");  
	        rd.include(request, response);
    	}else{
    	request.setAttribute("bookdetails", book);
    	RequestDispatcher dispatcher = request.getRequestDispatcher("View");
    	dispatcher.include(request, response);
    	out.println("<html><body><style>.form{text-align: center;}" +
    			".button{background-color: white;border: " +
    			"2px solid #4CAF50;border-radius: 8px;color: black;padding: 15px 32px;" +
    			"text-align: center;text-decoration: none;display: inline-block;font-size: 16px;" +
    			"margin: 4px 2px;transition-duration: 0.4s;cursor: pointer;}" +
    			".button:hover{background-color: #4CAF50;color: white;}</style>" +
    			"<form class=form><button class =button name=return formaction=/BookWeb/HomePage.html>Home Page" +
    			"</button></form></body></html>");
	}
    }
    private void update(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    	PrintWriter out = response.getWriter();
    	int bookID = Integer.parseInt(request.getParameter("bookid"));
    	Book book = dao.update(bookID);
    	if(book==null){
    		response.setContentType("text/html");
			out.println("Book Does not Exist");
	        RequestDispatcher rd=request.getRequestDispatcher("/HomePage.html");  
	        rd.include(request, response);
    	}else{
    	 	request.setAttribute("bookdetails", book);
        	RequestDispatcher dispatcher = request.getRequestDispatcher("Update");
        	dispatcher.include(request, response);
    	}
	}
    private void update2(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
    	PrintWriter out = response.getWriter();
    	//out.println("Update 2");
    	String bPublisher="";
    	int bID = Integer.parseInt(request.getParameter("bookid"));
    	String bName = request.getParameter("bookname");
    	String bAuthor = request.getParameter("bookauthor");
    	String bGenre = request.getParameter("genre");
    	int bPrice = Integer.parseInt(request.getParameter("price"));
    	String [] publArray = request.getParameterValues("Publishers");
    	String bDiscription = request.getParameter("description");
    	String bPublishingDate = request.getParameter("date");
    	for(String s : publArray){
    		bPublisher = bPublisher+s+",";
    	}
    	bPublisher = bPublisher.substring(0,bPublisher.length()-1);
    	Book book =new Book(bID, bName, bAuthor, bGenre, bPrice, bPublisher, bPublishingDate, bDiscription);
    	//System.out.println(book);
    	dao.update2(book);
    	out.print("Book Successfully Updated"); 
        response.setContentType("text/html");
        RequestDispatcher rd=request.getRequestDispatcher("/HomePage.html");  
        rd.include(request, response);  
	}

	private void delete(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    	PrintWriter out = response.getWriter();
    	int bookID = Integer.parseInt(request.getParameter("bookid"));
    	Book book = dao.view(bookID);
    	if(book==null){
    		response.setContentType("text/html");
			out.println("Book Does not Exist");
	        RequestDispatcher rd=request.getRequestDispatcher("/HomePage.html");  
	        rd.include(request, response);
    	}else{
    	dao.delete(bookID);
    	out.println("Book Successfully Deleted");
    	response.setContentType("text/html");
        RequestDispatcher rd=request.getRequestDispatcher("/HomePage.html");  
        rd.include(request, response);
    	}
	}
	private void viewall(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
		PrintWriter out = response.getWriter();
		out.println("View All Called");
		ArrayList<Book> al = (ArrayList<Book>) dao.view();
		if(al==null){
		response.setContentType("text/html");
		out.println("Book Does not Exist");
        RequestDispatcher rd=request.getRequestDispatcher("/HomePage.html");  
        rd.include(request, response);
		}
		else{
			response.setContentType("text/html");
			request.setAttribute("aldetails", al);
	    	RequestDispatcher dispatcher = request.getRequestDispatcher("ViewAll");
	    	dispatcher.include(request, response);
	    	out.println("<html><body><style>.form{text-align: center;}" +
	    			".button{background-color: white;border: " +
	    			"2px solid #4CAF50;border-radius: 8px;color: black;padding: 15px 32px;" +
	    			"text-align: center;text-decoration: none;display: inline-block;font-size: 16px;" +
	    			"margin: 4px 2px;transition-duration: 0.4s;cursor: pointer;}" +
	    			".button:hover{background-color: #4CAF50;color: white;}</style>" +
	    			"<form class=form><button class =button name=return formaction=/BookWeb/HomePage.html>Home Page" +
	    			"</button></form></body></html>");
		}
		
	}
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String type = request.getParameter("type");
		if (type.equals("save")) {
			save(request, response);
		}
		else if (type.equals("view")){
			view(request,response);
		}
		else if (type.equals("delete")){
			delete(request,response);
		}
		else if (type.equals("update"))
		{
			update(request,response);
		}
		else if (type.equals("update2"))
		{
			update2(request,response);
		}
		else if(type.equals("viewall")){
			viewall(request,response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String type = request.getParameter("type");
		if (type.equals("save")) {
			save(request, response);
		}
		else if (type.equals("view")){
			view(request,response);
		}
		else if (type.equals("delete")){
			delete(request,response);
		}
		else if (type.equals("update"))
		{
			update(request,response);
		}
		else if (type.equals("update2"))
		{
			update2(request,response);
		}
		else if(type.equals("viewall"))
		{
			viewall(request,response);
		}
		
	}
}
