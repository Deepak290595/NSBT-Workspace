package com.nucleus.model.connection;

import java.sql.Connection;

public class MySQLConnection implements ConnectionSetup {

	@Override
	public Connection createConnection() {
		// TODO Auto-generated method stub
		return null;
	}

}
