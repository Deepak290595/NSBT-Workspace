package com.nucleus.model.connection;



public class ConnectionFactory {
	public static ConnectionSetup getConnection(String connectionType){
		if(connectionType.equals("oracle"))
			return new OracleConnection();
		else if(connectionType.equals("mysql"))
			return new MySQLConnection();
		else
			return null;
		
	}
}
