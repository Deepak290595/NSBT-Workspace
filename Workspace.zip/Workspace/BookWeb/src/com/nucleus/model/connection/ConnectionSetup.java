package com.nucleus.model.connection;

import java.sql.Connection;

public interface ConnectionSetup {
	public Connection createConnection();
}
