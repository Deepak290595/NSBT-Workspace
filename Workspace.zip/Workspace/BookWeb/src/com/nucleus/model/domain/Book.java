package com.nucleus.model.domain;

import java.io.Serializable;

public class Book implements Serializable {
	private int bID;
	private String bName;
	private String bAuthor;
	private String bGenre;
	private int bPrice;
	private String bPublisher;
	private String bPublishingDate;
	private String bDiscription;
	public int getbID() {
		return bID;
	}
	public void setbID(int bID) {
		this.bID = bID;
	}
	public String getbName() {
		return bName;
	}
	public void setbName(String bName) {
		this.bName = bName;
	}
	public String getbAuthor() {
		return bAuthor;
	}
	public void setbAuthor(String bAuthor) {
		this.bAuthor = bAuthor;
	}
	public String getbGenre() {
		return bGenre;
	}
	public void setbGenre(String bGenre) {
		this.bGenre = bGenre;
	}
	public int getbPrice() {
		return bPrice;
	}
	public void setbPrice(int bPrice) {
		this.bPrice = bPrice;
	}
	public String getbPublisher() {
		return bPublisher;
	}
	public void setbPublisher(String bPublisher) {
		this.bPublisher = bPublisher;
	}
	public String getbPublishingDate() {
		return bPublishingDate;
	}
	public void setbPublishingDate(String bPublishingDate) {
		this.bPublishingDate = bPublishingDate;
	}
	public String getbDiscription() {
		return bDiscription;
	}
	public void setbDiscription(String bDiscription) {
		this.bDiscription = bDiscription;
	}
	public Book(int bID, String bName, String bAuthor, String bGenre,
			int bPrice, String bPublisher, String bPublishingDate,
			String bDiscription) {
		//super();
		this.bID = bID;
		this.bName = bName;
		this.bAuthor = bAuthor;
		this.bGenre = bGenre;
		this.bPrice = bPrice;
		this.bPublisher = bPublisher;
		this.bPublishingDate = bPublishingDate;
		this.bDiscription = bDiscription;
	}
	@Override
	public String toString() {
		return "bID=" + bID + ", bName=" + bName + ", bAuthor=" + bAuthor
				+ ", bGenre=" + bGenre + ", bPrice=" + bPrice + ", bPublisher="
				+ bPublisher + ", bPublishingDate=" + bPublishingDate
				+ ", bDiscription=" + bDiscription ;
	}
	
	
}
