package com.nucleus.model.dao;

public class BookDAOFactory {
	public static BookDAO getObject(String impType){
		if(impType.equals("rdbms"))
			return new BookRDBMSDAOImp();
		else if(impType.equals("xml"))
			return new BookXMLDAOImp();
		else
			return null;
		
	}
}
