package com.nucleus.model.dao;

import java.util.List;

import com.nucleus.model.domain.Book;

public interface BookDAO {
	public void save(Book book);
	public Book view(int bookID);
	public List<Book> view();
	public Book update(int bookID);
	public void delete(int bookID);
	public void update2(Book book);
}
