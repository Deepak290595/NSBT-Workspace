package com.nucleus.model.validation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.nucleus.model.domain.Book;

public class Validation {
	Pattern pattern;
	Matcher matcher;
	public boolean validate(Book book){
		if(validateNames(book)==true&&
				validateGenre(book)==true&&
				validateId(book)==true&&
				validatePublishers(book)==true)
			return true;
		else
			return false;
		
	}
	public boolean validateNames(Book book){
		final String REGEX = "^[A-Za-z ]+$";
		pattern = Pattern.compile(REGEX);
		matcher = pattern.matcher(book.getbName());
		matcher = pattern.matcher(book.getbAuthor());
	if(matcher.matches()==true&&book.getbName().length()!=0&&book.getbAuthor().length()!=0)
		return true;
	else
		return false;
		
	}
	public boolean validateId(Book book){
		final String REGEX = "^[0-9]+$";
		pattern = Pattern.compile(REGEX);
		matcher = pattern.matcher(""+book.getbID());
	if(matcher.matches()==true&&book.getbID()!=0)
		return true;
	else
		return false;
		
	}
	public boolean validateGenre(Book book){
		final String REGEX = "^[A-Za-z ]+$";
		pattern = Pattern.compile(REGEX);
		matcher = pattern.matcher(book.getbGenre());
		if(matcher.matches()==true&&book.getbGenre().length()!=0){
			return true;
		}
		else
			return false;
	}
	public boolean validatePublishers(Book book){
		final String REGEX = "^[A-Za-z ]+$";
		pattern = Pattern.compile(REGEX);
		matcher = pattern.matcher(book.getbPublisher());
		if(matcher.matches()==true&&book.getbPublisher().length()!=0){
			return true;
		}
		else
			return false;
	}
	
}
