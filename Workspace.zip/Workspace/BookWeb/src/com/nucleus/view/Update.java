package com.nucleus.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nucleus.model.domain.Book;

/**
 * Servlet implementation class Update
 */
@WebServlet("/Update")
public class Update extends HttpServlet {
	private static final long serialVersionUID = 1L;
    String checked;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Update() {
        super();
    }
    private String buttonFiction(String bGenre){
    	if(bGenre.equalsIgnoreCase("fiction"))
    		return "checked";
    	else
    		return "";
	}
    private String buttonScifi(String bGenre){
    	if(bGenre.equalsIgnoreCase("Scifi"))
    		return "checked";
    	else
    		return "";
	}
    private String buttonHistory(String bGenre){
    	if(bGenre.equalsIgnoreCase("history"))
    		return "checked";
    	else
    		return "";
	}
    private void update(HttpServletRequest request, HttpServletResponse response) throws IOException {
		PrintWriter out = response.getWriter();
		Book bookDetails = (Book) request.getAttribute("bookdetails");
		int bID = bookDetails.getbID();	
		String bname = bookDetails.getbName();
		String bAuthor = bookDetails.getbAuthor();
		String bGenre = bookDetails.getbGenre();
		int bPrice = bookDetails.getbPrice();
		String bPublishers = bookDetails.getbPublisher();
		String date[]=bookDetails.getbPublishingDate().split(" ");
		String bPublishingDate = date[0];
		String bDiscription = bookDetails.getbDiscription();
		//System.out.println(bGenre);
		//System.out.println(button(bGenre));
		out.println("<html><head><link rel='stylesheet' type='text/css' href='BookStyle.css'>" +
				"<script type='text/javascript' src='BookScript.js'></script>" +
				"</head><body><h1 align='center'>Update Book Details</h1><div class='center'>" +
				"<form action='BookServlet' name='book' onsubmit='return validateNewBookPage()'><input type='hidden' name ='type' value='update2'/>");
		out.println("<table align='center'><tr><td><label>Book ID</label></td><td>" +
				"<input type ='text' name='bookid' value='"+bID+"' readonly required/></td><tr><td><label>Book Name</label></td><td>" +
				"<input type ='text' name='bookname' value='"+bname+"'required/></td><tr><td><label>Book Author</label></td><td>" +
				"<input type ='text' name='bookauthor' value='"+bAuthor+"'required/></td></tr><tr><td><label>Genre</label></td><td>" +
				"<input type='radio' name='genre' value='fiction' "+buttonFiction(bGenre)+">Fiction<br>" +
				"<input type='radio' name='genre' value='Scifi' "+buttonScifi(bGenre)+">Sci-Fi<br>" +
				"<input type='radio' name='genre' value='History'"+buttonHistory(bGenre)+">History<br></td></tr><tr><td><label>Price</label></td><td>" +
				"<input type='text' name='price' value='"+bPrice+"'required></td></tr><tr><td><label>Publishers</label></td><td>" +
				"<input type='checkbox' name='Publishers' value='Pearson'"+(bPublishers.contains("Pearson")?"checked='checked'":"")+"/>Pearson<br>" +
				"<input type='checkbox' name='Publishers' value='McGraw-Hill'"+(bPublishers.contains("McGraw-Hill")?"checked='checked'":"")+"/>McGraw-Hill Education<br>" +
				"<input type='checkbox' name='Publishers' value='Arihant'"+(bPublishers.contains("Arihant")?"checked='checked'":"")+"/>Arihant Publications<br>" +
				"<input type='checkbox' name='Publishers' value='HindustanTimes'"+(bPublishers.contains("HindustanTimes")?"checked='checked'":"")+"/>HindustanTimes.com<br></td></tr><tr><td><label>Publication Date</label></td><td>" +
				"<input type='date' name='date' value='"+bPublishingDate+"'/></td></tr><tr><td><label>Description</label></td><td>" +
				"<textarea rows='4' cols='30' name='description'>"+bDiscription+"</textarea><br><br></td></tr></table>" +
				"<button type='submit' class='button' value='Update'>Update</button></form></div></body></html>");
		
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		update(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		update(request,response);
	}

}
