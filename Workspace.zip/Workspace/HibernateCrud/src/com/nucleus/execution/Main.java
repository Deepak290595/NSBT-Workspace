package com.nucleus.execution;

import java.util.Scanner;

import com.nucleus.dao.BookDAOImp;
import com.nucleus.domain.Book;

public class Main {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Book book = new Book();
		BookDAOImp imp = new BookDAOImp();
		System.out.println("---------Welcome--------");
		do{
		System.out.println("Choose the operation you want to perform: \n1.New \n2.View \n3.Delete \n4.Update \n6.View All \n5.Exit");
		int key = scanner.nextInt();
		switch (key) {
		case 1:
			System.out.println("Enter book Id : ");
			book.setBookID(scanner.nextInt());
			System.out.println("Enter book name: ");
			book.setBookName(scanner.next());
			imp.saveBook(book);
			System.out.println("Successfully Saved");
			break;
		case 2:
			System.out.println("Enter Book Id: ");
			book = imp.viewBook(scanner.nextInt());
			if(book==null){
				System.out.println("Oops no such book exist");
			}
			else
				System.out.println("Book details you asked for: "+book);
			break;
		case 3:
			System.out.println("Enter Book Id: ");
			imp.deleteBook(scanner.nextInt());
			System.out.println("Successfully Deleted");
			break;
		case 4:
			System.out.println("Enter Book Id : ");
			int bookID = scanner.nextInt();
			System.out.println("Old details" + imp.viewBook(bookID));
			System.out.println("Press 1 to update and 2 to go back to main menu: ");
			if(scanner.nextInt()==1){
				System.out.println("Enter Book Name : ");
				book.setBookID(bookID);
				book.setBookName(scanner.next());
				imp.updateBook(book);
				System.out.println("Book after Update: "+imp.viewBook(bookID));
				break;
			}
			break;
		case 5:
			System.out.println("Program Terminated");
			scanner.close();
			System.exit(0);
		case 6:
			System.out.println("All book details: ");
			System.out.println(imp.viewAllBooks());
			break;
		default:
			break;
		}
		}while(true);
	}
}
