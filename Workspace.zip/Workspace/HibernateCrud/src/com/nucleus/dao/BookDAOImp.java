package com.nucleus.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import com.nucleus.domain.Book;

public class BookDAOImp {
	Configuration configuration = new Configuration().configure("/com/nucleus/config/bookhibernate.cfg.xml");
	public void saveBook(Book book){
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		session.persist(book);
		transaction.commit();
		session.close();
	}
	public Book viewBook(int bookID){
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Book book = (Book) session.get(Book.class, bookID);
		transaction.commit();
		session.close();
		return book;
	}
	public void deleteBook(int bookID){
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Book book = new Book();
		book.setBookID(bookID);
		session.delete(book);
		transaction.commit();
		session.close();
	}
	public void updateBook(Book book){
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		session.update(book);
		transaction.commit();
		session.close();
	}
	public List<Book> viewAllBooks(){
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		List<Book> booklist= new ArrayList<>();
		booklist = session.createCriteria(Book.class).list();
		transaction.commit();
		session.close();
		return booklist;
	}
}
