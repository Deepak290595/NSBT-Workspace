package question1;

import java.util.Scanner;

public class Player {
	int sum =0;
	String st;
	static int n=0;
	char[] ch = new char[10];
	double avg=0;
	public void count(int count,String[]arr){
		for(int i = 0;i< count ; i++){
				st=arr[i];
				long a=Integer.parseInt(st);
				while(a>0){
				int k=(int)(a%10);
					sum=sum+k;
					a=a/10;
					System.out.println(sum);
				}
				avg=sum/st.length();
				sum = 0;
				if(avg>=5)
					n++;
		}
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Player p= new Player();
		System.out.println("Enter the number of players: ");
		int count = sc.nextInt();
		String[] arr=new String[count];
		for(int i=0;i<count;i++){
			System.out.println("Enter the wickets taken by player"+i);
			arr[i]=sc.next();
		}
		p.count(count, arr);
		System.out.println("Best Bowler: "+n);
		
		
	}

}
