package question2;

import java.util.Scanner;

public class T20Scores {
	public void decrypt(int machesPlayed,int[] arr){
		for(int i=0;i<arr.length;i++){
			for(int j=1;j<arr.length-1;i++)
			if(arr[i]==arr[i+1]){
				arr[j]=arr[j+1];
			}
		}
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of matches: ");
		int matchesPlayed = sc.nextInt();
		
	}

}
