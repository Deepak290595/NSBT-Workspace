package question2;
//Java Program to produce the multiplication table of 1 to 9
public class TimeTable			//Main class
{
static							//Static block will be invoked as main class loaded
{
System.out.println(" ");
System.out.print("*|");			//for printing * and | on console 
for (int i = 1; i <=9; i++)		//for loop to print columns numbers from 1-9
{
System.out.print(" "+i+" ");	//value of i will be printed till 9
}
System.out.println();			//for next line
System.out.println("-----------------------------");//to separate the rows
}

public static void main (String[] args)				//main method
{
for (int row = 1; row<=9; row++)					//for loop to print rows from 1-9
{
	System.out.print(""+row+"|");					//printing row number from 1-9
	System.out.print("");
for (int col = 1; col<=9; col++)					//for loop to calculate product of rows and column
{
int product = row * col;							//calculating product of rows and column
if (product < 10 )
System.out.print(" " + product + " ");				//printing product till 10
else
System.out.print(product + " ");					//printing product greater than 10
}
System.out.println(" ");
}
}
} 