package question3;
import java.util.Scanner;
//Java program to take n number of student grade as input and returning there average
public class Grade{
    private final int MIN_GRADE  = 0;		//Initializing minimum grade value
    private final int MAX_GRADE = 100;		//Initializing maximum grade value
    private int[] grades;					//Declaring array of grades
    Scanner in = new Scanner(System.in);	//Scanner class object
    private void run(int numStudents)		//Method to take input of grades and calculating grades
    {
        if (numStudents <= 0) {				//Checking for non positive numbers i.e <=0
            System.out.println("Invalid number of students.");	//Printing the text between inverted commas
            return;							//return statement
        }        
        grades = new int[numStudents];		//Assigning maximum array value
        double sum=0;						//Initializing sum as zero
        int    i= 0;						//Initializing i as zero	
        while (i<numStudents)				//While loop will run till i is less then array maximum value
        {
          System.out.printf("Enter the grade for student "+(i+1)+": "); //Asking for the grades for each student
            int grade = in.nextInt();									//taking input in local variable grade
            if ((grade >= MIN_GRADE) && (grade <= MAX_GRADE)) {			//Checking whether the entered value id between maximum and minimum value or not
                grades[i] = grade;										//Assigning value to grades array
                sum = sum + grade;										//Calculating sum of each grades
                i++;													//increasing i with 1 at every loop 
                continue;												
            }
            System.out.println("Invalid grade, try again...");			//Printing text between inverted text
        }
        double avg=sum/numStudents;										//Calculating Average
        System.out.printf("The average is: "+avg );						//Printing average
    }
    public static void main(String[] args)								//Main method
    {
    	Grade aG = new Grade();											//Creating object of class								
        System.out.print("Enter the number of students: ");				//Printing the text between inverted commas
        int numStudents = aG.in.nextInt();								//Initializing value of numofstudent
        aG.run(numStudents);											//Calling method run with numofstudent as parameter
    }
}
