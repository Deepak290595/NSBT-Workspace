package question1;
//Java Program to display the first 20 Fibonacci numbers And Display their Average
public class Fibb
{		//main method
	   public static void main(String[] args) {
		   double sum =0;  //initializing sum variable value
	       System.out.println("The first 20 Fibonacci numbers are: "); //display the text in double inverted commas
	       for (int i = 1; i <= 20; i++) {   //for loop to iterate from 1 to 20
	           System.out.print(fibonacci(i) + " ");	//calling function fibonacci
	           sum += fibonacci(i);						//calculating the sum of the value derived from the function
	       }
	       double average=sum/20;						//calculating average 
	       System.out.println();						//Printing next line
	       System.out.println("The average is "+average); //Printing the text in inverted commas with the result of average
	   }

	   public static int fibonacci(int n) {				// function for fibonnaci with parameter as n
	       if (n == 0) {								//if n equal to zero
	           return 0;								//return zero
	       } else if (n == 1) {							//if n equal to one
	           return 1;								//return 1
	       } else {										//else any other condition 
	           return fibonacci(n - 1) + fibonacci(n - 2);	//return fibonnaci of n-1 plus fibonacci of n-2
	       }
	   }
}
