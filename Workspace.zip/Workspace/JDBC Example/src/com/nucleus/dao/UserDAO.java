package com.nucleus.dao;

import com.nucleus.domain.User;

public interface UserDAO {
	public void signUp(User user);
	public boolean signIn(String id,String password);
	public void update(String id,String password);
	public void delete(String id);
	
}
