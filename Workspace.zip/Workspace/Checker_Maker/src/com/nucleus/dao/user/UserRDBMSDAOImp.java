package com.nucleus.dao.user;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.nucleus.connection.ConnectionFactory;
import com.nucleus.connection.ConnectionSetup;
import com.nucleus.model.domain.User;

public class UserRDBMSDAOImp implements UserDAO {
	ConnectionSetup connectionSetup = ConnectionFactory.getConnection("oracle");
	Connection connection;
	PreparedStatement preparedStatement;
	ResultSet resultSet;
	String uID;
	String uPsw;
	public UserRDBMSDAOImp(){
		connection = connectionSetup.createConnection();
	}
	@Override
	public boolean validateUser(String uName,String uPassword) {
		
		try {
			preparedStatement = connection.prepareStatement("select userid,password from user_deepak where userid = ?");
			preparedStatement.setString(1,uName);
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next()){
				uID= resultSet.getString(1);
				uPsw = resultSet.getString(2);
			}
			return uID.equalsIgnoreCase(uName)&&uPsw.equals(uPassword);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	@Override
	public User getUser(String uName) {
		try {
			preparedStatement = connection.prepareStatement("select user_deepak.userid,user_deepak.username,role_deepak.role " +
					" from user_deepak join role_deepak on user_deepak.rollid = role_deepak.rollid where userid = ?");
			preparedStatement.setString(1, uName);
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next()){
				String iD = resultSet.getString(1);
				String name = resultSet.getString(2);
				String role = resultSet.getString(3);
				return new User(iD, name, role);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

}
