package com.nucleus.dao.user;

import com.nucleus.model.domain.User;


public interface UserDAO {
	public boolean validateUser(String uname,String upsw);
	public User getUser(String uName);
}
