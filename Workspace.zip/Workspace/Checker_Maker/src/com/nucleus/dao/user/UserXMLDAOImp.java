package com.nucleus.dao.user;

import com.nucleus.model.domain.User;

public class UserXMLDAOImp implements UserDAO {

	@Override
	public boolean validateUser(String uname,String upsw) {
		return true;
	}

	@Override
	public User getUser(String uName) {
		return null;
	}

}
