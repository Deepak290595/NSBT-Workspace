package com.nucleus.dao.customer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.nucleus.connection.ConnectionFactory;
import com.nucleus.connection.ConnectionSetup;
import com.nucleus.model.domain.Customer;

public class CustomerRDBMSDAOImp implements CustomerDAO{
	ConnectionSetup connectionSetup = ConnectionFactory.getConnection("oracle");
	Connection connection;
	PreparedStatement preparedStatement;
	ResultSet resultSet;
	@Override
	public boolean save(Customer customer) {
		
		customer.setcRecordStatus("New");
		boolean unique=false;
		try {
			connection = connectionSetup.createConnection();
			preparedStatement = connection.prepareStatement("insert into customer_deepak values(?,?,?,?,?,?,?,?,?,?,SYSDATE,?,?,?,?,?)");
			preparedStatement.setString(1,customer.getcCode());
			preparedStatement.setString(2, customer.getcName());
			preparedStatement.setString(3, customer.getcAddress1());
			preparedStatement.setString(4, customer.getcAddress2());
			preparedStatement.setString(5, customer.getcPinCode());
			preparedStatement.setString(6, customer.getcEmail());
			preparedStatement.setString(7, customer.getcNumber());
			preparedStatement.setString(8, customer.getcPrimaryContactPerson());
			preparedStatement.setString(9,customer.getcRecordStatus() );
			preparedStatement.setString(10, customer.getcActiveInactiveFlag());
			preparedStatement.setString(11,customer.getCreatedBy());
			preparedStatement.setString(12, customer.getModifiedDate());
			preparedStatement.setString(13, customer.getModifiedBy());
			preparedStatement.setString(14, customer.getAuthorizedDate());
			preparedStatement.setString(15, customer.getAuthorizedBy());
			preparedStatement.executeQuery();
		} catch (SQLException e) {
			unique = true;
			return unique; 
		}finally {
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			connectionSetup.closeConnection(connection);
		}
		return unique;
	}

	@Override
	public List<Customer> view(String code) {
		List<Customer> customerList = new ArrayList<>();
		String []arr;
		String modifiedDate;
		String []arr1;
		try {
			connection = connectionSetup.createConnection();
			preparedStatement = connection.prepareStatement("select * from customer_deepak where code=?");
			preparedStatement.setString(1,code);
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next()){
				String cCode = resultSet.getString(1);
				String name = resultSet.getString(2);
				String address1 = resultSet.getString(3);
				String address2 = resultSet.getString(4);
				String pin = resultSet.getString(5);
				String mail = resultSet.getString(6);
				String num = resultSet.getString(7);
				String person = resultSet.getString(8);
				String status = resultSet.getString(9);
				String flag = resultSet.getString(10);
				String date = resultSet.getString(11);
				arr = date.split(" ");
				String createDate = arr[0];
				String createdBy = resultSet.getString(12);
				String mDate = resultSet.getString(13);
				if (mDate==null) {
					modifiedDate = mDate;
				}
				else{
					arr1 = mDate.split(" ");
					modifiedDate = arr1[0];					
				}
				String modifiedBy = resultSet.getString(14);
				String authorisedDate = resultSet.getString(15);
				String authorisedBy = resultSet.getString(16);
				customerList.add(new Customer(cCode, name, address1, address2, pin, 
						mail, num, person, status, flag, createDate, createdBy, modifiedDate, 
						modifiedBy, authorisedDate, authorisedBy));
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally {
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			connectionSetup.closeConnection(connection);
		}
		return customerList;
	}

	@Override
	public List<Customer> viewAll() {
		List<Customer> customerList = new ArrayList<>();
		String []arr;
		String modifiedDate;
		String []arr1;
		try {
			connection = connectionSetup.createConnection();
			preparedStatement = connection.prepareStatement("select * from customer_deepak");
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next()){
				String cCode = resultSet.getString(1);
				String name = resultSet.getString(2);
				String address1 = resultSet.getString(3);
				String address2 = resultSet.getString(4);
				String pin = resultSet.getString(5);
				String mail = resultSet.getString(6);
				String num = resultSet.getString(7);
				String person = resultSet.getString(8);
				String status = resultSet.getString(9);
				String flag = resultSet.getString(10);
				String date = resultSet.getString(11);
				arr = date.split(" ");
				String createDate = arr[0];
				String createdBy = resultSet.getString(12);
				String mDate = resultSet.getString(13);
				if (mDate==null) {
					modifiedDate = mDate;
				}
				else{
					arr1 = mDate.split(" ");
					modifiedDate = arr1[0];					
				}
				String modifiedBy = resultSet.getString(14);
				String authorisedDate = resultSet.getString(15);
				String authorisedBy = resultSet.getString(16);
				customerList.add(new Customer(cCode, name, address1, address2, pin, 
						mail, num, person, status, flag, createDate, createdBy, modifiedDate, 
						modifiedBy, authorisedDate, authorisedBy));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			connectionSetup.closeConnection(connection);
		}
		return customerList;
	}

	@Override
	public boolean delete(String code) {
		boolean exist=true;
		try {
			connection = connectionSetup.createConnection();
			preparedStatement = connection.prepareStatement("delete from customer_deepak where code=?");
			preparedStatement.setString(1, code);
			if(preparedStatement.executeUpdate() <= 0)
			{
				exist = false;
				return exist;
			}else{
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			connectionSetup.closeConnection(connection);
		}
		return true;
		
	}

	@Override
	public boolean update(Customer customer) {
		boolean updated = false;
		try {
			connection = connectionSetup.createConnection();
			preparedStatement = connection.prepareStatement("update customer_deepak set name=?,address1=?,address2=?,pin_code=?,email=?,ContactNumber=?,PriContPerson=?,RecordStatus=?,Active_inactive_flag=?,CreateDate=to_date(?,'YYYY-MM-DD'),CreatedBy=?,modifiedDate=SYSDATE,modifiedBy=?,authorizedDate=?,authorizedBy=? where code=?");
			preparedStatement.setString(1,customer.getcName());
			preparedStatement.setString(2, customer.getcAddress1());
			preparedStatement.setString(3,customer.getcAddress2());
			preparedStatement.setString(4, customer.getcPinCode());
			preparedStatement.setString(5, customer.getcEmail());
			preparedStatement.setString(6, customer.getcNumber());
			preparedStatement.setString(7, customer.getcPrimaryContactPerson());
			preparedStatement.setString(8, customer.getcRecordStatus());
			preparedStatement.setString(9, customer.getcActiveInactiveFlag());
			preparedStatement.setString(10, customer.getCreateDate());
			preparedStatement.setString(11, customer.getCreatedBy());
			preparedStatement.setString(12, customer.getModifiedBy());
			preparedStatement.setString(13, customer.getAuthorizedDate());
			preparedStatement.setString(14, customer.getAuthorizedBy());
			preparedStatement.setString(15, customer.getcCode());
			preparedStatement.executeUpdate();
			updated = true;
		} catch (SQLException e) {
			updated = false;
			e.printStackTrace();
		}finally{
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			connectionSetup.closeConnection(connection);
		}
		return updated;	
	}

	@Override
	public List<Customer> viewAllPagination(int number) {
		List<Customer> customerList = new ArrayList<>();
		String []arr;
		String modifiedDate;
		String []arr1;
		try {
			connection = connectionSetup.createConnection();
			preparedStatement = connection.prepareStatement("SELECT * FROM customermasterbydeepak ORDER BY custID1 OFFSET ? ROWS FETCH NEXT 10 ROWS ONLY");
			preparedStatement.setInt(1, number);
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next()){
				String cCode = resultSet.getString(1);
				String name = resultSet.getString(2);
				String address1 = resultSet.getString(3);
				String address2 = resultSet.getString(4);
				String pin = resultSet.getString(5);
				String mail = resultSet.getString(6);
				String num = resultSet.getString(7);
				String person = resultSet.getString(8);
				String status = resultSet.getString(9);
				String flag = resultSet.getString(10);
				String date = resultSet.getString(11);
				arr = date.split(" ");
				String createDate = arr[0];
				String createdBy = resultSet.getString(12);
				String mDate = resultSet.getString(13);
				if (mDate==null) {
					modifiedDate = mDate;
				}
				else{
					arr1 = mDate.split(" ");
					modifiedDate = arr1[0];					
				}
				String modifiedBy = resultSet.getString(14);
				String authorisedDate = resultSet.getString(15);
				String authorisedBy = resultSet.getString(16);
				customerList.add(new Customer(cCode, name, address1, address2, pin, 
						mail, num, person, status, flag, createDate, createdBy, modifiedDate, 
						modifiedBy, authorisedDate, authorisedBy));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			connectionSetup.closeConnection(connection);
		}
		return customerList;
	}


}
