package com.nucleus.dao.customer;

import java.util.List;
import com.nucleus.model.domain.Customer;

public interface CustomerDAO {
	public boolean save(Customer customer);
	public List<Customer> view(String code);
	public List<Customer> viewAll();
	public boolean delete(String code);
	public boolean update(Customer customer);
	public List<Customer> viewAllPagination(int number);
}
