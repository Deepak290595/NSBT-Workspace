package com.nucleus.dao.customer;

import java.util.Collections;
import java.util.List;

import com.nucleus.model.domain.Customer;

public class CustomerXMLDAOImp implements CustomerDAO {

	@Override
	public boolean save(Customer customer) {
		return false;
	}

	@Override
	public List<Customer> view(String code) {
		return Collections.emptyList();
	}

	@Override
	public List<Customer> viewAll() {

		return Collections.emptyList();
	}

	@Override
	public boolean delete(String code) {
		return false;

		
	}

	@Override
	public boolean update(Customer customer) {

		return false;
	}

	@Override
	public List<Customer> viewAllPagination(int number) {
		return Collections.emptyList();
	}
} 
