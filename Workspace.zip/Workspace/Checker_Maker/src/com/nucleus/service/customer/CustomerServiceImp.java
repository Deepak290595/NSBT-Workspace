package com.nucleus.service.customer;

import java.util.ArrayList;
import java.util.List;

import com.nucleus.dao.customer.CustomerDAO;
import com.nucleus.dao.customer.CustomerDAOFactory;
import com.nucleus.model.domain.Customer;

public class CustomerServiceImp implements CustomerService {
	CustomerDAO dao = CustomerDAOFactory.getObject("rdbms");
	List<Customer> customerList = new ArrayList<>();
	@Override
	public boolean save(Customer customer) {
		return dao.save(customer);
	}

	@Override
	public List<Customer> view(String code) {
		customerList = dao.view(code);
		return customerList;
	}

	@Override
	public List<Customer> viewAll() {
		customerList = dao.viewAll();
		return customerList;
	}

	@Override
	public boolean delete(String code) {
		return dao.delete(code);
	}

	@Override
	public Customer update1(String code) {
		try{
		return dao.view(code).get(0);
		}
		catch(Exception e){
			return null;
		}
	}
	@Override
	public boolean update2(Customer customer) {
		
		return dao.update(customer);
	}

	@Override
	public List<Customer> viewAllPagination(int number) {
		customerList = dao.viewAllPagination(number);
		return customerList;
	}

}
