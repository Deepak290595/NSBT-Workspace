package com.nucleus.service.customer;

import java.util.List;

import com.nucleus.model.domain.Customer;

public interface CustomerService {
	public boolean save(Customer customer);
	public List<Customer> view(String code);
	public List<Customer> viewAll();
	public boolean delete(String code);
	public Customer update1(String code);
	public boolean update2(Customer customer);
	public List<Customer> viewAllPagination(int number);
	
}
