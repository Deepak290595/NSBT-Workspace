package com.nucleus.service.customer;

import java.util.Collections;
import java.util.List;

import com.nucleus.model.domain.Customer;

public class CustomerXMLServiceImp implements CustomerService {

	@Override
	public boolean save(Customer customer) {

		return false;
	}

	@Override
	public List<Customer> view(String code) {

		return Collections.emptyList();
	}

	@Override
	public List<Customer> viewAll() {

		return Collections.emptyList();
	}

	@Override
	public boolean delete(String code) {

		return false;
	}

	@Override
	public Customer update1(String code) {

		return null;
	}

	@Override
	public boolean update2(Customer customer) {

		return false;
	}

	@Override
	public List<Customer> viewAllPagination(int number) {
		return Collections.emptyList();
	}

}
