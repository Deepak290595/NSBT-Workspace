package com.nucleus.service.user;

import com.nucleus.model.domain.User;

public class UserXMLServiceImp implements UserService {

	@Override
	public User getUser(String uName, String uPsw) {
		return null;
	}

}
