package com.nucleus.filter;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet Filter implementation class FilterWebpages
 */
@WebFilter(filterName = "FilterWebpages",urlPatterns = {"/CustomerServlet","/MakerMultiple.jsp","/MakerHome.jsp","/Update.jsp","/MakerNewCustomer.jsp","/View.jsp","/MakerViewAll.jsp","/ViewAllPagination.jsp","/MakerViewAllPagination.jsp"})
public class FilterWebpages implements Filter {

    /**
     * Default constructor. 
     */
    public FilterWebpages() {
    	//default condtructor not used
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		//Never used
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest)req;
		HttpServletResponse response = (HttpServletResponse)res;
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		String name = (String) session.getAttribute("UserName");
		if(name==null){
			out.println("<script type=\"text/javascript\">");
	     	out.println("alert('Not allowed.Please Login');");
	     	out.println("location='LoginPage.jsp';");
	     	out.println("</script>");
		}
		else
			chain.doFilter(req, res);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 * 
	 */
	
	public void init(FilterConfig fConfig) throws ServletException {
		//No parameters are initialised
	}

}
