package com.nucleus.model.domain;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Customer implements Serializable{
	private String cCode;
	private String cName;
	private String cAddress1;
	private String cAddress2;
	private String cPinCode;
	private String cEmail;
	private String cNumber;
	private String cPrimaryContactPerson;
	private String cRecordStatus;
	private String cActiveInactiveFlag;
	private String createDate;
	private String createdBy;
	private String modifiedDate;
	private String modifiedBy;
	private String authorizedDate;
	private String authorizedBy;
	public String getcCode() {
		return cCode;
	}
	public void setcCode(String cCode) {
		this.cCode = cCode;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getcAddress1() {
		return cAddress1;
	}
	public void setcAddress1(String cAddress1) {
		this.cAddress1 = cAddress1;
	}
	public String getcAddress2() {
		return cAddress2;
	}
	public void setcAddress2(String cAddress2) {
		this.cAddress2 = cAddress2;
	}
	public String getcPinCode() {
		return cPinCode;
	}
	public void setcPinCode(String cPinCode) {
		this.cPinCode = cPinCode;
	}
	public String getcEmail() {
		return cEmail;
	}
	public void setcEmail(String cEmail) {
		this.cEmail = cEmail;
	}
	public String getcNumber() {
		return cNumber;
	}
	public void setcNumber(String cNumber) {
		this.cNumber = cNumber;
	}
	public String getcPrimaryContactPerson() {
		return cPrimaryContactPerson;
	}
	public void setcPrimaryContactPerson(String cPrimaryContactPerson) {
		this.cPrimaryContactPerson = cPrimaryContactPerson;
	}
	public String getcRecordStatus() {
		return cRecordStatus;
	}
	public void setcRecordStatus(String cRecordStatus) {
		this.cRecordStatus = cRecordStatus;
	}
	public String getcActiveInactiveFlag() {
		return cActiveInactiveFlag;
	}
	public void setcActiveInactiveFlag(String cActiveInactiveFlag) {
		this.cActiveInactiveFlag = cActiveInactiveFlag;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getAuthorizedDate() {
		return authorizedDate;
	}
	public void setAuthorizedDate(String authorizedDate) {
		this.authorizedDate = authorizedDate;
	}
	public String getAuthorizedBy() {
		return authorizedBy;
	}
	public void setAuthorizedBy(String authorizedBy) {
		this.authorizedBy = authorizedBy;
	}
	public Customer(String cCode, String cName, String cAddress1,
			String cAddress2, String cPinCode, String cEmail, String cNumber,
			String cPrimaryContactPerson, String cRecordStatus,
			String cActiveInactiveFlag, String createDate, String createdBy,
			String modifiedDate, String modifiedBy, String authorizedDate,
			String authorizedBy) {
		super();
		this.cCode = cCode;
		this.cName = cName;
		this.cAddress1 = cAddress1;
		this.cAddress2 = cAddress2;
		this.cPinCode = cPinCode;
		this.cEmail = cEmail;
		this.cNumber = cNumber;
		this.cPrimaryContactPerson = cPrimaryContactPerson;
		this.cRecordStatus = cRecordStatus;
		this.cActiveInactiveFlag = cActiveInactiveFlag;
		this.createDate = createDate;
		this.createdBy = createdBy;
		this.modifiedDate = modifiedDate;
		this.modifiedBy = modifiedBy;
		this.authorizedDate = authorizedDate;
		this.authorizedBy = authorizedBy;
	}
	@Override
	public String toString() {
		return "Customer [cCode=" + cCode + ", cName=" + cName + ", cAddress1="
				+ cAddress1 + ", cAddress2=" + cAddress2 + ", cPinCode="
				+ cPinCode + ", cEmail=" + cEmail + ", cNumber=" + cNumber
				+ ", cPrimaryContactPerson=" + cPrimaryContactPerson
				+ ", cRecordStatus=" + cRecordStatus + ", cActiveInactiveFlag="
				+ cActiveInactiveFlag + ", createDate=" + createDate
				+ ", createdBy=" + createdBy + ", modifiedDate=" + modifiedDate
				+ ", modifiedBy=" + modifiedBy + ", authorizedDate="
				+ authorizedDate + ", authorizedBy=" + authorizedBy + "]";
	}
	
	}
