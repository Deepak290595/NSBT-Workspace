package com.nucleus.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.nucleus.model.domain.Customer;
import com.nucleus.service.customer.CustomerService;
import com.nucleus.service.customer.CustomerServiceFactory;
/**
 * Servlet implementation class Customer
 */
@WebServlet("/CustomerServlet")
public class CustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	HttpSession session;
	CustomerService customerService = CustomerServiceFactory.getObject("rdbms");
	Customer customer;
	List<Customer> customerList;
    public CustomerServlet() {
        super();
    }
    private void viewAllPagination(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
		PrintWriter out = response.getWriter();
		RequestDispatcher dispatcher; 
		String action = request.getParameter("action");
		if(action==null){
			request.setAttribute("pageNumber",0);
			int pageNumber = (int) request.getAttribute("pageNumber");
			customerList = customerService.viewAllPagination(pageNumber);
			request.setAttribute("customerDetails", customerList);
			dispatcher = request.getRequestDispatcher("ViewAllPagination.jsp");
			dispatcher.include(request, response);
		}
		else if(action.equals("Next")){
			int pageNumber = Integer.parseInt((String) request.getParameter("pageNumber"));
			customerList = customerService.viewAllPagination(pageNumber+10);
				if(customerList.isEmpty()){
					out.println("<script type=\"text/javascript\">");
					out.println("alert('No records found');");
					out.println("location='MakerHome.jsp';");
					out.println("</script>");
				}else
					{
					request.setAttribute("customerDetails", customerList);
					pageNumber = Integer.parseInt((String)request.getParameter("pageNumber"));
					request.setAttribute("pageNumber", pageNumber+10);
					dispatcher = request.getRequestDispatcher("ViewAllPagination.jsp");
					dispatcher.forward(request, response);
					}
		}
		else if(action.equalsIgnoreCase("previous")){
			int pageNumber = Integer.parseInt((String) request.getParameter("pageNumber"));
			customerList = customerService.viewAllPagination(pageNumber-10);
			if(customerList.isEmpty()){
				out.println("<script type=\"text/javascript\">");
			     out.println("alert('No records found');");
			     out.println("location='MakerHome.jsp';");
			     out.println("</script>");
			}else
			{
				request.setAttribute("customerDetails", customerList);
				pageNumber = Integer.parseInt((String) request.getParameter("pageNumber"));
				request.setAttribute("pageNumber", pageNumber-10);
				dispatcher = request.getRequestDispatcher("ViewAllPagination.jsp");
				dispatcher.forward(request, response);
			}
		}
		
		
		
		
	}

	private void viewall(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
		PrintWriter out = response.getWriter();
		customerList = customerService.viewAll();
		if(customerList.isEmpty()){
			out.println("<script type=\"text/javascript\">");
		     out.println("alert('No records found');");
		     out.println("location='MakerHome.jsp';");
		     out.println("</script>");
		}else
		{
			request.setAttribute("customerDetails", customerList);
			RequestDispatcher dispatcher = request.getRequestDispatcher("View.jsp");
			dispatcher.forward(request, response);
		}
		
		
	}


	private void delete(HttpServletRequest request, HttpServletResponse response) throws IOException {
		PrintWriter out = response.getWriter();
		String code = request.getParameter("code");
		if(customerService.delete(code)){
			out.println("<script type=\"text/javascript\">");
		    out.println("alert('Customer successfully deleted');");
		    out.println("location='MakerHome.jsp';");
		    out.println("</script>");
		}
		else
		{
			out.println("<script type=\"text/javascript\">");
		    out.println("alert('No Records Found');");
		    out.println("location='MakerHome.jsp';");
		    out.println("</script>");
		}
		
	}

	private void view(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String code = request.getParameter("code");
		customerList = customerService.view(code);
		if(customerList.isEmpty()){
			out.println("<script type=\"text/javascript\">");
		    out.println("alert('Customer code does not exist');");
		    out.println("location='MakerHome.jsp';");
		    out.println("</script>");
		}else
		{
			request.setAttribute("customerDetails", customerList);
			RequestDispatcher dispatcher = request.getRequestDispatcher("View.jsp");
			dispatcher.forward(request, response);
		}
	}

	private void save(HttpServletRequest request, HttpServletResponse response) throws IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		session = request.getSession();
		String creator = (String)session.getAttribute("UserName");
		String code = request.getParameter("code");
		String name = request.getParameter("name");
		String address1 = request.getParameter("address1");
		String address2 = request.getParameter("address2");
		String pin = request.getParameter("pin");
		String mail = request.getParameter("mail");
		String num = request.getParameter("num");
		String person = request.getParameter("person");
		String flag = request.getParameter("flag");
		customer = new Customer(code, name, address1, address2, pin, mail, num, person, "", flag, "", creator, "", "", "", "");
		if(customerService.save(customer))
		{	
			 out.println("<script type=\"text/javascript\">");
		     out.println("alert('Customer code already exist');");
		     out.println("location='MakerNewCustomer.jsp';");
		     out.println("</script>");
		}else
			{
			 out.println("<script type=\"text/javascript\">");
		     out.println("alert('Customer saved successfully');");
		     out.println("location='MakerHome.jsp';");
		     out.println("</script>");
			}
	}
	private void update2(HttpServletRequest request, HttpServletResponse response) throws IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		session = request.getSession();
		String modifier = (String)session.getAttribute("UserName");
		String code = request.getParameter("code");
		String name = request.getParameter("name");
		String address1 = request.getParameter("address1");
		String address2 = request.getParameter("address2");
		String pin = request.getParameter("pin");
		String mail = request.getParameter("mail");
		String num = request.getParameter("num");
		String person = request.getParameter("person");
		String flag = request.getParameter("flag");
		String createDate = request.getParameter("createDate");
		String createdBy = request.getParameter("createdBy");
		customer = new Customer(code, name, address1, address2, pin, mail, num, person, "Modified", flag,createDate, createdBy, "", modifier, "", "");
		if(customerService.update2(customer)){
		out.println("<script type=\"text/javascript\">");
	    out.println("alert('Customer updated successfully');");
	    out.println("location='MakerHome.jsp';");
	    out.println("</script>");
		}
		else{
			out.println("<script type=\"text/javascript\">");
		    out.println("alert('Error Encountered in updating');");
		    out.println("location='MakerHome.jsp';");
		    out.println("</script>");
		}
		
	}
	
	private void update(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		PrintWriter out = response.getWriter();
		String code = request.getParameter("code");
		if(customerService.update1(code)==null)
		{
			out.println("<script type=\"text/javascript\">");
		    out.println("alert('No records found');");
		    out.println("location='MakerHome.jsp';");
		    out.println("</script>");
		}
		else{
			request.setAttribute("customerDetails", customerService.update1(code));
			RequestDispatcher dispatcher = request.getRequestDispatcher("Update.jsp");
			dispatcher.include(request, response);
		}
	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String type = request.getParameter("type");
		try{
			if (type.equals("save")) {
				save(request, response);
			}
			else if (type.equals("view")){
				view(request,response);
			}
			else if (type.equals("delete")){
				delete(request,response);
			}
			else if (type.equals("update")){
				update(request,response);
			}
			else if(type.equals("viewall")){
				viewall(request,response);
			}
			else if(type.equals("update2")){
				update2(request,response);
			}
			else if(type.equals("viewallpagination")){
				viewAllPagination(request, response);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String type = request.getParameter("type");
		try{
			if (type.equals("save")) {
				save(request, response);
			}
			else if (type.equals("view")){
				view(request,response);
			}
			else if (type.equals("delete")){
				delete(request,response);
			}
			else if (type.equals("update")){
				update(request,response);
			}
			else if(type.equals("viewall")){
				viewall(request,response);
			}
			else if(type.equals("update2")){
				update2(request,response);
			}
			else if(type.equals("viewallpagination")){
				viewAllPagination(request, response);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
}
