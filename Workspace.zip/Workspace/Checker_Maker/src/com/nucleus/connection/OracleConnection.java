package com.nucleus.connection;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class OracleConnection implements ConnectionSetup {
	Connection connection;
	public Connection createConnection(){
		Properties properties = new Properties();
		try { 
			properties.load(this.getClass().getResourceAsStream("ConnectionDetails.properties"));
			String driverClass = properties.getProperty("MYSQLJDBC.driver");
			String url = properties.getProperty("MYSQLJDBC.url");
			String username = properties.getProperty("MYSQLJDBC.username");
			String pass = properties.getProperty("MYSQLJDBC.password");
			Class.forName(driverClass);
			connection = DriverManager.getConnection(url,username,pass); 
		} catch (ClassNotFoundException|SQLException|IOException e) {
			e.printStackTrace();
		}
		return connection;
		
	}
	public void closeConnection(Connection connection){
		if(connection!=null){
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
