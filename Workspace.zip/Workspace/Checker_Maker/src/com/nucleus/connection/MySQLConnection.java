package com.nucleus.connection;

import java.sql.Connection;

public class MySQLConnection implements ConnectionSetup {

	@Override
	public Connection createConnection() {

		return null;
	}

	@Override
	public void closeConnection(Connection connection) {
		//Not implemented yet
	}

}
