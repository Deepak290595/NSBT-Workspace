package com.nucleus.validation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.nucleus.model.domain.Customer;


public class Validation {
	Pattern pattern;
	Matcher matcher;
	
	public boolean validate(Customer customer){
		Validation validation= new Validation();
		return validation.validateCode(customer)&&
				validation.validateName(customer)&&
				validation.validateAddress1(customer)&&
				validation.validatePincode(customer)&&
				validation.validateEmail(customer)&&
				validation.validatePrimary(customer);
	}
	public boolean validateCode(Customer customer){
		return customer.getcCode().length()!=0&&customer.getcCode().length()<=10 /*&& !arrayList.contains(customer.getcCode())*/ /*checkCustCode(arrayList, customer.getcCode())*/ ;
		}
	public boolean validateName(Customer customer){
		pattern = Pattern.compile("^[A-Za-z0-9 ]+$");
		matcher = pattern.matcher(customer.getcName());
		return matcher.matches()&&customer.getcName().length()!=0 &&customer.getcName().length()<=30;
	}
	public boolean validateAddress1(Customer customer){
		return customer.getcAddress1().length()!=0;
		}
	public boolean validatePincode(Customer customer){
		pattern = Pattern.compile("^[0-9]{6}$");
		matcher = pattern.matcher(customer.getcPinCode());
				
		return matcher.matches()&&customer.getcPinCode().length()!=0;
	}
	public boolean validateEmail(Customer customer){
		pattern = Pattern.compile("^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$");
		matcher = pattern.matcher(customer.getcEmail());
		return matcher.matches()&&customer.getcEmail().length()!=0;
	}
	public boolean validatePrimary(Customer customer){
		return customer.getcPrimaryContactPerson().length()!=0;
		}
}
