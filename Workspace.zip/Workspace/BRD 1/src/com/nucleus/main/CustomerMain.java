package com.nucleus.main;

import java.util.Scanner;
import com.nucleus.dao.* ;

public class CustomerMain {								//Class public available within and outside package
	public static void main(String[] args) {			//Main method execution will start from here
		Scanner scanner = new Scanner(System.in);		//Scanner class object
		System.out.print("Enter the file path: ");		//Asking for the path
		String filePath = scanner.nextLine();			//Initializing the file path with the user given value
		System.out.print("Enter file name: ");			//Asking for file name
		String filename = scanner.nextLine();			//Initializing the file name with user given input
		while(!(filename.substring(filename.length()-4, filename.length()).equals(".txt"))){		//checking for the extension of text file
			System.out.println("Enter the correct file name");										//if wrong extension input again
			filename = scanner.nextLine();															//Initializing the file name with user given input
		}
		String file = filePath+"\\"+filename;														//Appending file path and file name in a single string
		file.replace("\\", "/");																	//Replacing "\\" with "/"
		CustomerDAO daoImp = CustomerDAOFactory.getObject("rdbms");
		System.out.println("Choose the rejection level: \n1.R - Record level rejection\n2.F - File level rejection"); //Asking the user for rejection level
		int choice = scanner.nextInt();										//Initializing choice with user given input			
			switch (choice) {												//Switch operating with the parameter as choice
		case 1:																//Switch Case1 
			//CustomerDAOImp daoImp = new CustomerDAOImp();					//Creating Object of CustomerDAOImp
			
			daoImp.fileRead(file, choice);									//Calling parameterized method of CustomerDAOImp class
			break;															//Break
		case 2:																//Switch Case 2
																			//Creating Object of CustomerDAOImp
			daoImp.fileRead(file, choice);									//Calling parameterized method of CustomerDAOImp class
			break;															//Break
		}
	}
}
