package com.nucleus.dao;

import com.nucleus.domain.Customer;							//Importing package com.nucleus.domain.Customer

public interface CustomerDAO {								//Interface CustomerDAO
	public void fileRead(String file, int rej);				//Parameterized Methods without definition(abstract)
	public void tableWrite(Customer customer, int rej);		//Parameterized Methods without definition(abstract)
}
