package com.nucleus.connection;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class OracleConnection implements ConnectionSetup {
	Connection connection;
	public Connection createConnection(){
		Properties properties = new Properties();
		try {
			//InputStream stream = new FileInputStream("ConnectionDetails.properties");
			//properties.load(stream);
			properties.load(this.getClass().getResourceAsStream("ConnectionDetails.properties"));
			String driverClass = properties.getProperty("MYSQLJDBC.driver");
			String url = properties.getProperty("MYSQLJDBC.url");
			String username = properties.getProperty("MYSQLJDBC.username");
			String pass = properties.getProperty("MYSQLJDBC.password");
			Class.forName(driverClass);
			connection = DriverManager.getConnection(url,username,pass); 
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
		
	}
}
