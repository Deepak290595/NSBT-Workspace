package com.nucleus.connection;

import java.sql.Connection;

public interface ConnectionSetup {
	public Connection createConnection();
}
