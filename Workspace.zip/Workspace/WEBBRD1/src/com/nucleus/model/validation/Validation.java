package com.nucleus.model.validation;

import java.util.ArrayList;
import java.util.regex.*;

import com.nucleus.model.domain.Customer;
import com.nucleus.model.error.ErrorLog;

public class Validation {
	Pattern pattern;
	Matcher matcher;
	ErrorLog log = new ErrorLog();
	public boolean checkCustCode(ArrayList<String> arrayList, String custCode)
	{
		int count = 0;
		for(String s:arrayList)
		{
			if(s.equals(custCode))
				++count;
		}
		if(count>1)
			return true;
		else
			return false;
	}
	
	public boolean validate(Customer customer,ArrayList<String> arrayList){
		Validation validation= new Validation();
		if(validation.validateCode(customer,arrayList)==true&&
				validation.validateName(customer)==true&&
				validation.validateAddress1(customer)==true&&
				validation.validatePincode(customer)==true&&
				validation.validateEmail(customer)==true&&
				validation.validatePrimary(customer)==true&&
				validation.validateRecord(customer)==true&&
				validation.validateFlag(customer)==true&&
				validation.validateDate(customer)==true&&
				validation.validateCreator(customer)==true)
			return true;
		else
			return false;
	}
	public boolean validateCode(Customer customer,ArrayList<String> arrayList){
		if(customer.getcCode().length()!=0&&customer.getcCode().length()<=10 && !arrayList.contains(customer.getcCode()) /*checkCustCode(arrayList, customer.getcCode())*/ )
			return true;
		else
			log.error("Error in Customer code: "+customer.getcCode());
			return false;
		}
	public boolean validateName(Customer customer){
		final String REGEX = "^[A-Za-z0-9 ]+$";
		pattern = Pattern.compile(REGEX);
		matcher = pattern.matcher(customer.getcName());
	if(matcher.matches()==true&&customer.getcName().length()!=0 &&customer.getcName().length()<=30)
		return true;
	else
		log.error("Error in Customer Name: "+customer.getcName());
		return false;
	}
	public boolean validateAddress1(Customer customer){
		if(customer.getcAddress1().length()!=0)
			return true;
		else
			log.error("Error in Address1: "+customer.getcAddress1());
			return false;
		}
	public boolean validatePincode(Customer customer){
		final String REGEX = "^[0-9]{6}$";
		pattern = Pattern.compile(REGEX);
		matcher = pattern.matcher(customer.getcPinCode());
				
		if(matcher.matches()==true&&customer.getcPinCode().length()!=0)
			return true;
		else
			log.error("Error in Pincode: "+customer.getcPinCode());
			return false;
	}
	public boolean validateEmail(Customer customer){
		final String REGEX =  "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
		pattern = Pattern.compile(REGEX);
		matcher = pattern.matcher(customer.getcEmail());
		if(matcher.matches()==true&&customer.getcEmail().length()!=0)
			return true;
		else
			log.error("Error in email: "+customer.getcEmail());
			return false;
	}
	public boolean validatePrimary(Customer customer){
		if(customer.getcPrimaryContactPerson().length()!=0)
			return true;
		else
			log.error("Error in primary contact person: "+customer.getcPrimaryContactPerson());
			return false;
		}
	public boolean validateRecord(Customer customer){
		final String REGEX = "^[A]|[N]|[D]|[R]|[M]$";
		pattern  = Pattern.compile(REGEX);
		matcher = pattern.matcher(customer.getcRecordStatus());
		if(matcher.matches()==true&&customer.getcRecordStatus().length()!=0)
			return true;
		else
			log.error("Error in record status: "+customer.getcRecordStatus());
			return false;
	}
	public boolean validateFlag(Customer customer){
		final String REGEX = "^[A]|[I]$";
		pattern = Pattern.compile(REGEX);
		matcher = pattern.matcher(customer.getcActiveInactiveFlag());
		if(matcher.matches()==true&&customer.getcActiveInactiveFlag().length()!=0)
			return true;
		else
			log.error("Error in active/inactive flag: "+customer.getcActiveInactiveFlag());
			return false;
	}
	public boolean validateDate(Customer customer){
		if(customer.getcCreateDate().length()!=0)
			return true;
		else
			log.error("Error in created date: "+customer.getcCreateDate());
			return false;
		}
	public boolean validateCreator(Customer customer){
		if(customer.getcCreatedBy().length()!=0)
			return true;
		else
			log.error("Error in created by: "+customer.getcCreatedBy());
			return false;
		}
}
