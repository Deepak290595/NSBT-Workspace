package com.nucleus.model.error;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import com.nucleus.model.domain.Customer;


public class ErrorLog {
	FileWriter fileWriter;
	PrintWriter printWriter;
	public void error(String error){
		try {
			fileWriter = new FileWriter("C:/Users/temp/Desktop/errorlog.txt",true);
			printWriter = new PrintWriter(fileWriter);
			printWriter.format("%s\n", error);
			printWriter.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void ErrorLogprint(Customer customer) {
		try {
			fileWriter = new FileWriter("C:/Users/temp/Desktop/errorlog.txt",true);
			printWriter = new PrintWriter(fileWriter);
			printWriter.format("%s\n", customer);
			printWriter.flush();
		} catch (IOException e) {
			e.printStackTrace();
			//System.out.println("IO Exceptioon");
		}
		finally{
			try {
				fileWriter.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				//System.out.println("IO Exception");
			}
		}
	}
}
