package com.nucleus.model.dao;

import com.nucleus.model.domain.Customer;

public interface CustomerDAO {								//Interface CustomerDAO
	public void fileRead(String file, int rej);				//Parameterized Methods without definition(abstract)
	public void tableWrite(Customer customer, int rej);		//Parameterized Methods without definition(abstract)
}
