package com.nucleus.model.dao;

import com.nucleus.model.domain.Customer;

public class CustomerXMLDAOImp implements CustomerDAO {

	@Override
	public void fileRead(String file, int rej) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void tableWrite(Customer customer, int rej) {
		// TODO Auto-generated method stub
		
	}

}
