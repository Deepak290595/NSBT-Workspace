package com.nucleus.model.dao;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import com.nucleus.model.connection.ConnectionSetup;
import com.nucleus.model.domain.Customer;
import com.nucleus.model.error.ErrorLog;
import com.nucleus.model.validation.Validation;


public class CustomerRDBMSDAOImp implements CustomerDAO{				//Class CustomerDAOImp implements CustomerDao Interface		
	ConnectionSetup connectionSetup = new ConnectionSetup();	//Creating object of Class ConnectionSetup	
	Connection connection;										//Reference variable of class Connection
	ErrorLog log = new ErrorLog();
	public CustomerRDBMSDAOImp(){									//Constructor of CustomerDAOImp
		connection = connectionSetup.createConnection();		//Initializing connection variable
		try {													
			connection.setAutoCommit(false);					//Setting auto commit as false
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	ArrayList<String> arrayList= new ArrayList<String>(); 		//Creating Object of ArrayList class
	FileReader fileReader;										//Declaring reference variable of FileReader class		
	Customer customer;											//Declaring reference variable of Customer class
	Validation validation=new Validation();						//Creating object of Validation class
	PreparedStatement preparedStatement;						//Declaring reference variable of PreparedStatement interface
	@Override													//Overriding method from CustomerDAO interface
	public void fileRead(String file, int rej) {				//Parameterized overridden method of CustomerDAOImp
		CustomerRDBMSDAOImp customerDAOImp =  new CustomerRDBMSDAOImp();	//Creating class of class CustomerDAOImp
		boolean errorFound = false;								//Initializing a boolean variable errorFound
		try {
			fileReader = new FileReader(file);									//Creating object of FileReader with file path and name as parameter
			BufferedReader bufferedReader = new BufferedReader(fileReader);		//Passing the fileReader reference variable in BufferedReader object
			String string = bufferedReader.readLine();							//Reading the line from file and storing in string
			int iD =1;															//Initializing integer iD as 1
			while(string!=null){												//While loop till the end of file
				String [] arrOfStr = string.split("~",-1);						//Splitting the string on "~" till the end of line and storing in arrOfStr
				String code = arrOfStr[0];										//Initializing code
				String name = arrOfStr[1];										//Initializing name
				String address1 = arrOfStr[2];									//Initializing address1
				String address2 = arrOfStr[3];									//Initializing address2
				String pin =arrOfStr[4];										//Initializing pin
				String email = arrOfStr[5];										//Initializing email
				String num = arrOfStr[6];										//Initializing num
				String person = arrOfStr[7];									//Initializing person
				String status = arrOfStr[8];									//Initializing status
				String flag = arrOfStr[9];										//Initializing flag
				String cDate = arrOfStr[10];									//Initializing cDate
				String createdBy = arrOfStr[11];								//Initializing createdBy
				String mDate = arrOfStr[12];									//Initializing mDate
				String modifiedBy = arrOfStr[13];								//Initializing modifiedBy
				String aDate = arrOfStr[14];									//Initializing aDate
				String authorisedBy = arrOfStr[15];
				Customer customer = new Customer(iD,code,name,address1,address2,pin,	//Creating object of customer class
						email,num,person,status,flag,cDate,createdBy,mDate,modifiedBy,
						aDate,authorisedBy);
				if(validation.validate(customer,arrayList)==true){				//Checking for validation
					customerDAOImp.tableWrite(customer, rej);					//If all validation are true then call for tableWrite method
					System.out.println(iD+"=========="+customer);				//Printing customer object on console
				}
				else{															//Else all validation are not true
					errorFound = true;											//Set errorFound true
					log.ErrorLogprint(customer);									//Calling the parameterized constructor of ErrorLog
				}	
				arrayList.add(code);											//Adding the code to arrayList
				iD++;															//Incrementing iD
				string = bufferedReader.readLine();								//
				
			}
			
			if(rej == 2)
			{
				try
				{
					System.out.println(errorFound);
					if(errorFound)
					{
						System.out.println("rollback");
						customerDAOImp.connection.rollback();
					}
					else
					{	
						customerDAOImp.connection.commit();
						System.out.println("commit");
					}
				}
				catch(SQLException e){ 
					e.printStackTrace();
				}
			}
		}catch (FileNotFoundException e) {
			e.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}finally{
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Override
	public void tableWrite(Customer customer, int rej) {
		try {
			preparedStatement = connection.prepareStatement("insert into customermasterbydeepak values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			preparedStatement.setLong(1, customer.getcID());
			preparedStatement.setString(2,customer.getcCode());
			preparedStatement.setString(3,customer.getcName());
			preparedStatement.setString(4,customer.getcAddress1());
			preparedStatement.setString(5,customer.getcAddress2());
			preparedStatement.setString(6,customer.getcPinCode());
			preparedStatement.setString(7,customer.getcEmail());
			preparedStatement.setString(8,customer.getcNumber());
			preparedStatement.setString(9,customer.getcPrimaryContactPerson());
			preparedStatement.setString(10,customer.getcRecordStatus());
			preparedStatement.setString(11,customer.getcActiveInactiveFlag());
			preparedStatement.setString(12,customer.getcCreateDate());
			preparedStatement.setString(13,customer.getcCreatedBy());
			preparedStatement.setString(14,customer.getcModifiedDate());
			preparedStatement.setString(15,customer.getcModifiedBy());
			preparedStatement.setString(16,customer.getcAuthorizedDate());
			preparedStatement.setString(17,customer.getcAuthorizedBy());
			preparedStatement.executeUpdate();
			
			if(rej == 1)
			{
				connection.commit();
				System.out.println("committed");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//System.out.println("Connection error");
		}finally{
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
			}
	}
