package com.nucleus.controller;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.nucleus.model.dao.CustomerDAO;
import com.nucleus.model.dao.CustomerDAOFactory;

/**
 * Servlet implementation class CustomerController
 */
@WebServlet("/CC")
public class CustomerController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CustomerController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String location = request.getParameter("custfile");
		String rejection = request.getParameter("rejection");
		int rej;
		if(rejection.equals("Record"))
			rej=1;
		else
			rej=2;
		CustomerDAO dao = CustomerDAOFactory.getObject("rdbms");
		dao.fileRead(location, rej);
		FileReader fileReader = new FileReader("C:\\Users\\temp\\Desktop\\errorlog.txt");
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		String string = bufferedReader.readLine();
		out.println("<html><h1 align=center>Error Log File</h1>");
		out.println("<body><style>.center {padding: 70px 0;border: 3px solid green;}</style>");
		out.println("<div class=center>");
		while(string!=null){
			out.println(string+"<br><br>");
			string = bufferedReader.readLine();
		}
		out.println("</div></body></html>");
		bufferedReader.close();
	}

}
