package com.nucleus.filter;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

/**
 * Servlet Filter implementation class SpeacialCaseFilter
 */
//@WebFilter("/F1")
public class SpecialCaseFilter implements Filter {

    /**
     * Default constructor. 
     */
    public SpecialCaseFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		PrintWriter out = response.getWriter();
		String name=request.getParameter("name");
		if(name.contains("@")){
			name = name.replaceAll("@","");
			request.setAttribute("name1", name);
			chain.doFilter(request, response);
		}
			chain.doFilter(request, response);
			out.println("<br>Filter 1 running");
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
