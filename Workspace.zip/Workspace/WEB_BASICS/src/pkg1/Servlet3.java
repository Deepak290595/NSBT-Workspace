package pkg1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Servlet3
 */
//@WebServlet("/S3")
public class Servlet3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlet3() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("Welcome to Servlet 3");
		//ServletConfig servletConfig = getServletConfig();
		Enumeration<String> e = request.getHeaderNames();
		String string="";
		while(e.hasMoreElements()){
			string = e.nextElement();
			out.println("<br>Names: "+string);
			out.println("Values: "+request.getHeader(string));
		}
		ServletContext servletContext = getServletContext();
		String s = servletContext.getInitParameter("Contact Person");
		out.print(s);
		for(String s1:s.split(",")){
			out.println("<br>Email: "+s1);
		}
		}
	}

