

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TableServlet
 */
@WebServlet("/TableServlet")
public class TableServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TableServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		int num1 = Integer.parseInt(request.getParameter("firstnum"));
		int num2 = Integer.parseInt(request.getParameter("secondnum"));
		out.println("<html>");
		out.println("<h1 align=center>Tables</h1>");
		out.println("<body><style>.center {padding: 70px 0;border: 3px solid green;text-align: center;}</style>");
		out.println("<div class=center><table style=width:100% align=center>");
		for(int i =1;i<=10;i++){
			out.println("<tr><tr>");
			for(int j=num1;j<=num2;j++){
				out.println("<td ><td>");
				if(i%2==0){
					out.println("<font color=red>"+i*j+"</font>");
				}else
				out.println("<font color=blue>"+i*j+"</font>");
			}
			out.println("</td></td>");
			out.println("</tr></tr>");
		}
		out.println("</table></div></body></html>");
	}

}
