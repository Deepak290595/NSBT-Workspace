

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class StudentServlet
 */
@WebServlet("/SS")
public class StudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		Marks marks = new Marks();
		String fname = request.getParameter("firstname");
		String lname = request.getParameter("lastname");
		String roll = request.getParameter("rollno");
		int num = Integer.parseInt(request.getParameter("Marks"));
		if(request.getParameter("display")!=null){
			out.println("<html>");
			out.println("<h1 align=center>Student Result</h1>");
			out.println("<body><style>.center {padding: 70px 0;border: 3px solid green;text-align: center;}</style>");
			out.println("<div class=center>");
			out.println("Student Name: "+fname+" "+lname+"<br>");
			out.println("Roll No. : "+roll+"<br>");
			out.println("Marks: "+num+"<br>");
			out.println("Maximum Marks: "+50+"<br>");
			out.println(marks.percentage(num)+"%<br>");
			out.println(marks.grade(num));
			out.println("</div></body></html>");
		}
		
		
		
	}

}
