
public class Table {
	public void getTable(){
		int num1=2;
		int num2=5;
		for(int i=num1;i<=num2;i++){
			for(int j=1;j<=10;j++)
				System.out.println(i*j);
		}
	}
}
