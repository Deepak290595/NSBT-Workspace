
public class Marks {
	double percentage;
	public String percentage(int marks){
			percentage = (marks*100)/50;
			System.out.println(percentage);
		return "Percentage is: "+percentage;
		
	}
	public String grade(int marks){
		if(marks>=40)
			return "Grade: " +'A';
		else if (marks<40&&marks>=30)
			return "Grade: " + 'B';
		else if (marks<30&&marks>=20)
			return "Grade: " + 'C';
		else /*if (marks<20&&marks>=10)*/
			return "Grade: " + 'D';
			
					
	}
}
