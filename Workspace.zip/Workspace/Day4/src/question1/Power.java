package question1;

import java.text.DecimalFormat;
import java.util.Scanner;

public class Power {
	
	public static void main(String[] args) {
	        DecimalFormat df=new DecimalFormat("##.##");
	        Scanner input=new Scanner(System.in);
	        System.out.print("Enter Number: ");
	        double num=input.nextDouble();
	        System.out.print("Raise Number's power: ");
	        double pow=input.nextDouble();
	        double value=Math.pow(num,pow);
	        System.out.println("Result is: "+df.format(value));
	}
}
