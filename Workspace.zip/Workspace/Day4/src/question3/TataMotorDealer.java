package question3;

import java.util.Scanner;

public class TataMotorDealer extends ModelOfCategory {

	void checkCondition(String s)
	{
		switch (s) {
		case "SUV":
			super.category(s);
			break;
		case "SEDAN":
			super.category(s);
			break;
		case "ECONOMY":
			super.category(s);
			break;
		case "MINI":
			super.category(s);
			break;
		default:
			super.category(s);
		}
	}
	
	public static void main(String[] args) {
		TataMotorDealer tata=new TataMotorDealer();
		Scanner scanner = new Scanner(System.in);
		System.out.println("Which Category...");
		System.out.println("\n SUV \n SEDAN \n ECONOMY \n MINI \n");
		String s=scanner.next();
		tata.checkCondition(s);
		scanner.close();
		
		

	}

}
