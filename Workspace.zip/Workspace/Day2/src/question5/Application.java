package question5;
import java.util.Scanner;

class Application {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int k = 4;
		while (k-- > 0) {
			System.out.println("Choose\n1.To create Vehicle object\n2.To create Car Object\n3.To create Convertible object" +
					"\n4.To create Sportscar object");
			int test = s.nextInt();
			int noOfWheels, noOfPassengers, model, noOfDoors;
			boolean isHoodOpen;
			String make;
			switch (test) {
			case 1:
				System.out.println("Enter number of wheels: ");
				noOfWheels = s.nextInt();
				System.out.println("Enter number of passengers: ");
				noOfPassengers = s.nextInt();
				System.out.println("Enter model: ");
				model = s.nextInt();
				System.out.println("Enter make:");
				make = s.next();
				vehicle ob = new vehicle(noOfWheels, noOfPassengers, model,make);
				ob.display();
				System.out.println();
				break;
			case 2:
				System.out.println("Enter number of wheels:");
				noOfWheels = s.nextInt();
				System.out.println("Enter number of passengers: ");
				noOfPassengers = s.nextInt();
				System.out.println("Enter model: ");
				model = s.nextInt();
				System.out.println("Enter no. of Doors: ");
				noOfDoors = s.nextInt();
				System.out.println("Enter make:");
				make = s.next();
				car ob1 = new car(noOfWheels, noOfPassengers, model, noOfDoors,make);
				ob1.display();
				System.out.println();
				break;
			case 3:
				System.out.println("Enter number of wheels:");
				noOfWheels = s.nextInt();
				System.out.println("Enter number of passengers: ");
				noOfPassengers = s.nextInt();
				System.out.println("Enter model: ");
				model = s.nextInt();
				System.out.println("Enter no. of Doors: ");
				noOfDoors = s.nextInt();
				System.out.println("Is hood open: \nEnter true or false to answer");
				isHoodOpen = s.nextBoolean();
				System.out.println("Enter make:");
				make = s.next();
				Convertible ob2 = new Convertible(noOfWheels, noOfPassengers,model, noOfDoors, isHoodOpen, make);
				ob2.display();
				System.out.println();
				break;
			case 4:
				System.out.println("Enter number of wheels:");
				noOfWheels = s.nextInt();
				System.out.println("Enter number of passengers: ");
				noOfPassengers = s.nextInt();
				System.out.println("Enter model: ");
				model = s.nextInt();
				System.out.println("Enter make:");
				make = s.next();
				SportsCar ob3 = new SportsCar(noOfWheels, noOfPassengers,model, make);
				ob3.display();
				System.out.println();
				break;
			default:
				System.out.println("Wrong Input");
				break;
			}
		}
	}
}
