package question5;

class car extends vehicle
{
  private int noOfdoors;

 //inherited value
  car(int noOfWheels, int noOfPassengers, int model, int noOfDoors, String make)
   {
      super(noOfWheels, noOfPassengers, model, make);
      this.noOfdoors = noOfDoors;
  }



  public String getdoors()
  {
      return "No. of doors are " + this.noOfdoors;
  }




@Override
  public void display()
{
      System.out.println(getmake());
      System.out.println(getmodel());
      System.out.println(getdoors());
  }
}




