package question1;

import java.text.DecimalFormat;
import java.util.Scanner;
//Java Program to get circle area
public class Circle {
      	private final double PI = 3.14159;			//final value of PI
	   	private double radius;						//private radius variable of double type
	   // private String color="Red";				//private color of string type with value red
	   public Circle() 								//Default Constructor
      {
	        radius = 0.0;
	    }
	   
      public Circle(double r) {								//Parameterized Constructor
	        radius = r;
	    }
      public void setRadius(double r) 						//Setter method
      {
	        radius = r;
	    }
      public double getRadius() 							//getter method
      {
	        return radius;
	    }
      public double getArea() 								//getter Area method
      {
	        return PI * radius * radius;
	    }
      public static void main(String[] args) 					//main method
      {
    	  DecimalFormat df=new DecimalFormat("##.###");			//Decimal format class object
       
          Scanner sc = new Scanner(System.in);					// Create a Scanner object for input.

          
          System.out.print("Enter the radius of a circle: ");	//input circle radius
          double radius = sc.nextDouble();

          
          sc.close();											// close sc

          
          Circle circle1 = new Circle();						// Create a Circle object passing in user input
          Circle circle2 = new Circle(radius);
          
          System.out.println("Area is " + df.format(circle2.getArea()));	// Display circle information

      }
}



