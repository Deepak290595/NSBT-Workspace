package question3;

import java.util.Random;

public class RandNumGen {

	public String random() {

		Random rand = new Random();
		String num = "" + rand.nextInt(10) + rand.nextInt(10)
				+ rand.nextInt(10) + rand.nextInt(10) + rand.nextInt(10);
		return num;
	}
}
