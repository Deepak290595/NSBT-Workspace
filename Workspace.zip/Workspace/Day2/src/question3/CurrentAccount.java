package question3;


public class CurrentAccount extends Account {

	int tradeLicenseNumber;

	public CurrentAccount(String accountHolderName, double accountBalance) {
		super(accountHolderName, accountBalance, "");
	}

	void deposit(double deposit) {
		super.setAccountBalance((super.getAccountBalance() + deposit));

	}

	void withdraw(double deposit) {
		if (super.getAccountBalance() > deposit) {
			super.setAccountBalance((super.getAccountBalance() - deposit));
		} else {
			System.out.println("balance can not be exceed than account balance");
		}

	}

}
