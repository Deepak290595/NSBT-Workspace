package question3;


import java.util.Scanner;

public class Banking {
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the account name");
		String name = scanner.next();

		System.out.println("Choice the type of account ");
		System.out.println("Press 1 for saving account"+ "\n" +"Press 2 for cuurent account");
		int n = scanner.nextInt();

		System.out.println("Enter initial balance");

		double balance = scanner.nextDouble();

		double bal = balance + 5.0 / 100 * balance;

		if (n == 1) {
			SavingAccount savingaccount = new SavingAccount(name, bal);
			// savingaccount.setAccountBalance();
			do{
			System.out.println("Choose from the below choices: ");
			System.out.println("1 for deposit money "+"\n" +"2 for withdraw money"+"\n"+"3 for display the account balance"+"\n"+"4 Exit");
			int c = scanner.nextInt();
			switch (c) {
			case 1:
				System.out.println("Enter money to deposit");
				double deposit = scanner.nextDouble();

				savingaccount.deposit(deposit);
				savingaccount.display();
				break;
			case 2:
				System.out.println("Enter money to withdraw");
				double withdraw = scanner.nextDouble();
				savingaccount.withdraw(withdraw);
				savingaccount.display();
				break;
			case 3:
				savingaccount.display();
				break;
			case 4:
				System.exit(4);

			}
			}while(true);
		}
		if (n == 2) {
			CurrentAccount currentaccount = new CurrentAccount(name, balance);
			do{
			System.out.println("Choose from the below choices: ");
			System.out.println("1 for deposit money "+"\n" +"2 for withdraw money"+"\n"+"3 for display the account balance"+"\n"+"4 Exit");
			int input = scanner.nextInt();
			switch (input) {
			case 1:
				System.out.println("Enter money to deposit");
				double deposit = scanner.nextDouble();

				currentaccount.deposit(deposit);
				currentaccount.display();
				break;
			case 2:
				System.out.println("Enter money to withdraw");
				double withdraw = scanner.nextDouble();
				currentaccount.withdraw(withdraw);
				// savingaccount.display();
				break;
			case 3:
				currentaccount.display();
				break;
			case 4:
				System.exit(4);
			}
		}while(true);
		}
		scanner.close();
	}
}
