package question2;

public class Book {										//Public class Book
	private String bookTitle;							//Private String Book Title
	private String author;								//Private String Author
	private String iSBN;								//Private String ISBN
	private int numOfCopies;							//Private integer No. of copies
	public String getBookTitle() {						//Getter for Book Title
		return bookTitle;
	}
	public void setBookTitle(String bookTitle) {		//Setter for Book Title
		this.bookTitle = bookTitle;
	}
	public String getAuthor() {							//Getter for Author
		return author;
	}
	public void setAuthor(String author) {				//Setter for Author
		this.author = author;
	}
	public String getiSBN() {							//Getter for ISBN
		return iSBN;
	}
	public void setiSBN(String iSBN) {					//Setter for ISBN
		iSBN = iSBN;
	}
	public int getNumOfCopies() {						//Getter for number of copies
		return numOfCopies;
	}
	public void setNumOfCopies(int numOfCopies) {		//Setter for number of copies
		this.numOfCopies = numOfCopies;
	}
	Book(){												//Book constructor with default values
		 this("null","null","null",0);
	}
	public Book(String bookTitle, String author, String iSBN, int numOfCopies) {               //Book parameterized constructor
		this.bookTitle = bookTitle;
		this.author = author;
		this.iSBN = iSBN;
		this.numOfCopies = numOfCopies;
	}
	void display(){
		System.out.println(this.bookTitle+"-"+this.author+"-"+this.iSBN+"-"+this.numOfCopies); //Display method to print details of book
	}
	

}
