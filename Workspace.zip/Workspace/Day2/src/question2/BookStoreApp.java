package question2;
import java.util.Scanner;
public class BookStoreApp {
	public static void main(String[] args) {
		BookStore b= new BookStore();
		Scanner sc = new Scanner(System.in);
		b.initialize();
		
		do{
		System.out.println("Choose Option from the below Choices:"+"\n"+"1.Display"+"\n"+"2.Order"+"\n"+"3.Sell"+"\n"+"4.Exit");
		int n= sc.nextInt();
		switch(n){
		case 1:
			b.display();
			break;
		case 2:
			System.out.println("Enter Book ISBN: ");
			String iSBN =sc.next();
			System.out.println("Enter no. of copies: ");
			int noc = sc.nextInt();
			b.order(iSBN, noc);
			break;
		case 3:
			System.out.println("Enter Book Title: ");
			String title =sc.next();
			System.out.println("Enter no. of copies: ");
			int no = sc.nextInt();
			b.sell(title,no);
			break;
		case 4:
			System.out.println("Program terminated");
			System.exit(0);
		default:
			System.out.println("Enter correct Choice");
			break;
		}
	}while(true);
	}

}
