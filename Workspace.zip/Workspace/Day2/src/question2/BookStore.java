package question2;
import java.util.Scanner;
public class BookStore {											//Public class Book Store
	public Book books[];											//User defined array of book class
	int num;														//Declaring variable of integer type
	String Title,Author,ISBN;										//Declaring variables of string type
	int Copies;														//Declaring variable of integer type
	Scanner sc = new Scanner(System.in);							//Scanner class object
	public void initialize(){										//Initialize method to initialize values of different attributes of book
		System.out.println("Enter no. of books: ");					//Printing the text between inverted commas
		num = sc.nextInt();											//Assigning value to num
		books = new Book[10];										//Assigning value to the array
		for(int i=0;i<num;i++){										//for loop from zero to num	
			System.out.println("Enter Book Title: ");				//Asking to enter book title
			Title=sc.next();										//Assigning value to instance variable
			System.out.println("Enter author: ");					//Asking to enter book title
			Author=sc.next();										//Assigning value to instance variable
			System.out.println("Enter ISBN: ");						//Asking to enter book title
			ISBN=sc.next();											//Assigning value to instance variable
			System.out.println("Enter no. of copies: ");			//Asking to enter book title
			Copies=sc.nextInt();									//Assigning value to instance variable
			books[i]=new Book(Title,Author,ISBN,Copies);			//Assigning values to book array
		}
	}
	public BookStore(Book[] books) {								//Book Store constructor with parameter as book array
		this.books = books;
	}
	public BookStore() {											//No parameter constructor
	}
	void sell(String bookTitle,int noOfCopies){						//method sell to sell the book
		for (int i = 0; i < num; i++) {								//For loop iterating through book array
		if(books[i].getBookTitle().equalsIgnoreCase(bookTitle)){	//Checking whether the book title is in array or not
			books[i].setNumOfCopies(books[i].getNumOfCopies()-noOfCopies);	//if it is then decrease the number of copies
		}
		else{															
			System.out.println("Book not found...");				//Else book not found		
		}
		}
	}
	void order(String iSBN,int noOfCopies){							//Method order to add new book
		for(int i=0;i<=num;i++){										//for loop to iterate through array
			if(books[i].getiSBN().equalsIgnoreCase(iSBN)){			//checking for ISBN number in array
				books[i].setNumOfCopies(books[i].getNumOfCopies()+noOfCopies);	//if match found then increase the number of copies
			}
			else{	
				num++;
				System.out.println("New Book"+"\n"+"Enter details");//Else new book details to be add
				System.out.println("Enter Book Title: ");			//Asking for book title
				Title=sc.next();									//Storing book title
				System.out.println("Enter author: ");				//Asking for book author
				Author=sc.next();									//Storing book author
				System.out.println("Enter ISBN: ");					//Asking for book ISBN
				ISBN=sc.next();										//Storing book ISBN
				System.out.println("Enter no. of copies: ");		//Asking for book Copies
				Copies=sc.nextInt();								//Storing book Copies
				books[num+1]=new Book(Title,Author,ISBN,Copies);
			}
		}
	}
	void display(){
		System.out.println("Books Details:");
		for(int i =0;i<num;i++){
			System.out.println(books[i].getBookTitle()+"-"+books[i].getAuthor()+"-"+books[i].getiSBN()+"-"+books[i].getNumOfCopies());
		}
	}
	
}
