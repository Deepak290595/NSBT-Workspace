package question4;

public class Student
{
	String name;
	String id;
	double grade;
	
	public Student(String name,String id,double grade) {
		this.name=name;
		this.id=id;
		this.grade=grade;
	}
	
	public Student(String name, String id)
	{
		this(name,id,0.0);
		this.name=name;
		this.id=id;
		
	}
	
	public Student(String id)
	{
		this(null,id,0.0);
		this.id=id;
	}
	
	 void display()
	{
		System.out.println("Student name: "+name+" Student id: "+id+" Student grade: "+grade);
	}
	
	void display(int currentYear)
	{
		System.out.println("Student name: "+name+" Student id: "+id+" Student grade: "+grade+" Current year of the student"+currentYear);
		display();
	}
}