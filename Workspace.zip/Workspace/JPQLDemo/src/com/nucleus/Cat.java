package com.nucleus;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Cat {
	@Id
	private int catID;
	private String catName;
	private String catColour;
	public int getCatID() {
		return catID;
	}
	public void setCatID(int catID) {
		this.catID = catID;
	}
	public String getCatName() {
		return catName;
	}
	public void setCatName(String catName) {
		this.catName = catName;
	}
	public String getCatColour() {
		return catColour;
	}
	public void setCatColour(String catColour) {
		this.catColour = catColour;
	}
	@Override
	public String toString() {
		return "Cat [catID=" + catID + ", catName=" + catName + ", catColour=" + catColour + "]";
	}
	
}
