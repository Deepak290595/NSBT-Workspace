package com.nucleus;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Main {
	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("cat");
		EntityManager manager = factory.createEntityManager();
		manager.getTransaction().begin();
		/*Cat cat1 = new Cat();
		cat1.setCatID(1);
		cat1.setCatName("cat1");
		cat1.setCatColour("black");
		Cat cat2 = new Cat();
		cat2.setCatID(2);
		cat2.setCatName("cat2");
		cat2.setCatColour("White");
		manager.persist(cat1);
		manager.persist(cat2);*/
		
		//Get All data
		/*Query query = manager.createQuery("from Cat");
		System.out.println(query.getResultList());*/
		
		//Get Single result
		/*Query query = manager.createQuery("from Cat where catID=1");
		System.out.println(query.getSingleResult());*/
		
		//Update data
		/*Query query = manager.createQuery("Update Cat set catColour=? where catID=?");
		query.setParameter(0, "White");
		query.setParameter(1, 1);
		query.executeUpdate();*/
		
		//Delete data
		Query query = manager.createQuery("Delete from Cat where catID=?");
		query.setParameter(0, 1);
		query.executeUpdate();
		manager.getTransaction().commit();
//		System.out.println(cat1+" "+cat2);
		System.out.println("Done");
	}
}
