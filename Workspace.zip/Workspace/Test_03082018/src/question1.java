import java.util.Scanner;

public class question1 {
	
	public static void output_function(int num_player, String status)
	{
		int output=0;
		int player = 1;
		int initial = 0;
		String[] arr =status.split(",");
		int last = arr.length;
		for(String s : arr)
		{
			int length = s.length();
			int sum = 0;
			int val=0;
			for(int i=0;i<s.length();i++)
			{
				if(initial == 0)
				{
					i++;
					initial++;
					length--;
				}
				char c= s.charAt(i);
				if(c == '}')
				{
					sum = sum + 0;
					length--;
				}
				else
				{
				    val = c-48;
					sum = sum + val;
				}
			}	
		   if((sum/length) >= 5)
				{System.out.println("Player"+player);output++;}
			else
			{
				System.out.println("Not Player"+player);
			}
			player++;
		}
		System.out.println("Total Player: "+output);
	}

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the number of player: ");
		int num_player = in.nextInt();
		System.out.println("Enter the player Record:");
		String status = in.next();
		output_function(num_player,status);

	}

}
