import java.util.Scanner;

public class question2 {
	static int output=0;
    static int flag =0;
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the matrix val");
		int x = in.nextInt();
		int y= in.nextInt();
		char[][] arr = new char[x][y];
		System.out.println("Enter Input Values:");
		for(int i=0;i<x;i++)
		{
			for(int j=0;j<y;j++)
				arr[i][j]=in.next().charAt(0);
		}
		System.out.println("Enter output Values:");
		char c= in.next().charAt(0);
		for(int i=0;i<x;i++)
		{
			for(int j=0;j<y;j++)
			{
				int val = arr[i][j];
				int ans= c;
				if(val == ans)
				{
					flag = 1;
					break;
				}
			}
		if(flag == 1)
			break;
		}
		if(flag == 1)
			System.out.println("Strong");
		else
			System.out.println("Weak");
	}

}
