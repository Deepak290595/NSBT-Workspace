function validateform(){  
var name=document.forms["regform"]["fname"];
var pnum=document.forms["regform"]["pnum"];
var phoneno = /^\d{10}$/;
if (name==null || name==""){  
  window.alert("Name can't be blank");  
  return false;  
	}
  else if(pnum.value.match(phoneno)){
	return true;  
  	}
	else{
  	window.alert("Only number allowed in phone number fields");
	  return true;
  	}
 
}