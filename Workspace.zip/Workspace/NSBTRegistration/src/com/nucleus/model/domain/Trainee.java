package com.nucleus.model.domain;

public class Trainee {
	private String sFName;
	private String sLName;
	private char Gender;
	private String sFatherName;
	private long sPhoneNum;
	private long sFatherPhNum;
	private String sCollgName;
	private double sClgPercentage;
	private double s12thPercentage;
	private double s10thPercentage;
	public String getsFName() {
		return sFName;
	}
	public void setsFName(String sFName) {
		this.sFName = sFName;
	}
	public String getsLName() {
		return sLName;
	}
	public void setsLName(String sLName) {
		this.sLName = sLName;
	}
	public String getsFatherName() {
		return sFatherName;
	}
	public void setsFatherName(String sFatherName) {
		this.sFatherName = sFatherName;
	}
	public long getsPhoneNum() {
		return sPhoneNum;
	}
	public void setsPhoneNum(long sPhoneNum) {
		this.sPhoneNum = sPhoneNum;
	}
	public long getsFatherPhNum() {
		return sFatherPhNum;
	}
	public void setsFatherPhNum(long sFatherPhNum) {
		this.sFatherPhNum = sFatherPhNum;
	}
	public String getsCollgName() {
		return sCollgName;
	}
	public void setsCollgName(String sCollgName) {
		this.sCollgName = sCollgName;
	}
	public double getsClgPercentage() {
		return sClgPercentage;
	}
	public void setsClgPercentage(double sClgPercentage) {
		this.sClgPercentage = sClgPercentage;
	}
	public double getS12thPercentage() {
		return s12thPercentage;
	}
	public void setS12thPercentage(double s12thPercentage) {
		this.s12thPercentage = s12thPercentage;
	}
	public double getS10thPercentage() {
		return s10thPercentage;
	}
	public void setS10thPercentage(double s10thPercentage) {
		this.s10thPercentage = s10thPercentage;
	}
	public char getGender() {
		return Gender;
	}
	public void setGender(char gender) {
		Gender = gender;
	}
	
}
