package com.nucleus.model.dao;

import com.nucleus.model.domain.Trainee;

public interface TraineeDAO {
	public void save(Trainee trainee);
}
