package question1;

public class HourlyEmployee extends Employee{
	double hourlyRate;
	private int hourPerWeek;
	public int getHourPerWeek() {
		return hourPerWeek;
	}

	public void setHourPerWeek(int hourPerWeek) {
		this.hourPerWeek = hourPerWeek;
	}

	@Override
	public double getPayment() {
		
		return 0;
	}

	@Override
	double getSalary() {
		return this.hourlyRate*this.hourPerWeek*7;
		
	}

	@Override
	void setSalary(double rate) {
		this.hourlyRate=rate;
	}
	
}
