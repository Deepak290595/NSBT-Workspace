package question1;

public class SalariedEmployee extends Employee {
	double weeklyRate;
	@Override
	public double getPayment() {
		return 0;
	}

	@Override
	double getSalary() {
		return this.weeklyRate*7;
		
	}

	@Override
	void setSalary(double rate) {
		this.weeklyRate=rate;
	}

}
