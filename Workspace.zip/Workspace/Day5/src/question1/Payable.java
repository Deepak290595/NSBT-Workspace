package question1;

public interface Payable {
	double getPayment();
}
