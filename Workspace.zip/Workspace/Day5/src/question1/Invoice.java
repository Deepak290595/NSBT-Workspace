package question1;

public class Invoice implements Payable{
	private String partNum;
	private String partDescription;
	private int quantity;
	private double pricePerItem;
	public String getPartNum() {
		return partNum;
	}
	public void setPartNum(String partNum) {
		this.partNum = partNum;
	}
	public String getPartDescription() {
		return partDescription;
	}
	public void setPartDescription(String partDescription) {
		this.partDescription = partDescription;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getPricePerItem() {
		return pricePerItem;
	}
	public void setPricePerItem(double pricePerItem) {
		this.pricePerItem = pricePerItem;
	}
	
	public String toString(){
		return "Part Number : " +partNum+ "\nPart Description : "+partDescription+"\nQuantity : "+quantity+"\nPrice per Item : " +pricePerItem;
	}
	@Override
	public double getPayment() {
		// TODO Auto-generated method stub
		return 0;
	}


}
