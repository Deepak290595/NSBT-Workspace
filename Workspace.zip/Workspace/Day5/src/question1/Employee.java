package question1;

public abstract class Employee implements Payable{
	private String Ename;
	private String Etype;
	public void initialize(){
		
	}
	public String getEname() {
		return Ename;
	}
	public void setEname(String ename) {
		Ename = ename;
	}
	public String getEtype() {
		return Etype;
	}
	public void setEtype(String etype) {
		Etype = etype;
	}
	abstract double getSalary();
	abstract void setSalary(double rate);
}
