package question1;
import java.util.Scanner;

public class Application {
	public static void main(String[] args) {
		int input;
		Scanner sc = new Scanner(System.in);
		System.out.println("Welcome to Payable.....");
		System.out.println("Choose..."+"\n1.Employee\n2.Invoice");
		input=sc.nextInt();
			if(input==1){
				System.out.println("Coose one of the following option to display weekly salary: "+"\n1.Salaried Employee\n2.Hourly Employee\n3.Commission employee");
				int n = sc.nextInt();
				switch(n){
				case 1:
					SalariedEmployee se = new SalariedEmployee();
					System.out.println("Enter the weekly rate: ");
					se.setSalary(sc.nextDouble());
					System.out.println("Weekly salary: "+se.getSalary());
					break;
				case 2:
					HourlyEmployee he = new HourlyEmployee();
					System.out.println("Enter the hourly rate: ");
					he.setSalary(sc.nextDouble());
					System.out.println("Enter hours per week: ");
					he.setHourPerWeek(sc.nextInt());
					System.out.println("Weekly salary: "+he.getSalary());
					break;
				case 3:
					CommissionEmployee ce = new CommissionEmployee();
					System.out.println("Enter the percentage: ");
					ce.setSalary(sc.nextDouble());
					System.out.println("Enter the weekly sale:");
					ce.setWeeklySale(sc.nextInt());
					System.out.println("Weekly salary: "+ce.getSalary());
					break;
					
				}
		}
			else if(input==2){
					Invoice i = new Invoice();
					System.out.println(i.toString());
		}
		else{
			System.out.println("Choose Correct option");
			return;
	}}
	}

