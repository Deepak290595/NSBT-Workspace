package question1;

public class CommissionEmployee extends Employee{
	double percentage;
	private int weeklySale;
	
	public int getWeeklySale() {
		return weeklySale;
	}

	public void setWeeklySale(int weeklySale) {
		this.weeklySale = weeklySale;
	}

	@Override
	public double getPayment() {
		return 0;
	}

	@Override
	double getSalary() {
		return (this.weeklySale*this.percentage)/100;
		
	}

	@Override
	void setSalary(double rate) {
		this.percentage=rate;
	}


}
