package SMS;
import java.util.*;
//student class
class student{
	//private instance integer variable available whitin class only
	private int Stdid;
	//private instance string variable available whitin class only
	private String Sname;
	//private instance array variable available whitin class only
	private int[] marks;
	//getter
	public int getStdid() {
		return Stdid; //return value
	}
	//setter
	public void setStdid(int stdid) {
		Stdid = stdid; //assign value
	}
	//getter
	public String getSname() {
		return Sname; //return value
	}
	//setter
	public void setSname(String sname) {
		Sname = sname; //assign value
	}
	//getter
	public int[] getMarks() {
		return marks; //return value
	}
	//setter
	public void setMarks(int[] marks) {
		this.marks = marks; //assign array values
	}
	//Method to calculate average of elements of array of any sixe
	public double avg(int[]marks){
		//initialize sum variable
		int sum=0;
		int avg;
		//for loop to traverse elements in array 
		for(int i = 0 ; i < marks.length;i++){
			sum = sum+marks[i]; //compute sum
		}
		avg = sum/marks.length;	//compute average
		return avg; //return value
	}	
}
//Main class
public class studentManagementSystem {
	//Main method
	public static void main(String[] args) {
		student s1 = new student(); //object creation 
		Scanner sc = new Scanner(System.in); // opening scanner class
		System.out.println("Enter name of student : ");
		s1.setSname(sc.nextLine()); //taking string input
		System.out.println("Enter Roll no. of "+s1.getSname()+" : ");
		s1.setStdid(sc.nextInt()); //taking integer input
		System.out.println("Enter the number of subjects : ");
		int n = sc.nextInt();
		int[] marks = new int[n]; // array initialization
		for(int i = 0; i < n; i++){
			System.out.println("Enter "+(i+1)+" numbered subject's marks");
			marks[i] = sc.nextInt(); //assigning value
		}
		s1.setMarks(marks); //calling set marks
		System.out.println(s1.getSname()+" with rollno "+s1.getStdid()+" has "
				+n+" subject's Average : "+s1.avg(marks));
		int[] x = s1.getMarks();
		for(int i=0; i<x.length;i++){
			System.out.println("Subject" +(i+1) +" = "+x[i]);
		}
		sc.close();//scanner close
}
}
