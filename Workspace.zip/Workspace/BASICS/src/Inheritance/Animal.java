package Inheritance;
public class Animal {
/*	private String colour;
	private String name;
	public String getColour() {
		return colour;
	}
	public void setColour(String colour) {
		this.colour = colour;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void eat(Animal a){
		System.out.println(a.name+" is eating");
	}
	public void sound(Animal a){
		System.out.println(a.name+" is making sound");
	}*/
	//input method with parameter as reference variable
	public void input(Animal a){
		//if instance of parent class is Dog child
		if(a instanceof Dog){
			//following lines will execute
			Dog d = new Dog();
			d.input();
			d.eat(d);
			d.sound(d);
		}
		//else cat child
		else{
			Cat c= new Cat();
			c.input();
			c.eat(c);
			c.sound(c);
		}
	}
}
