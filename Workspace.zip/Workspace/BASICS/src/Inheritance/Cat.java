package Inheritance;
import java.util.Scanner;
public class Cat extends Animal {
	//String type 
	private String ccolour;
	private String cname;
	//getter
	public String getCcolour() {
		return ccolour;
	}
	//setter
	public void setCcolour(String ccolour) {
		this.ccolour = ccolour;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	//Input method to take input for dog class
	public void input(){
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Name of Cat : ");
		setCname(sc.nextLine());	//taking cat name as input
		System.out.println("Enter Colour of Cat : ");
		setCcolour(sc.nextLine());	//taking cat color as input
	}
	//eat method taking animal reference variable as parameter
	public void eat(Animal a){
		Cat c = (Cat)a;
		System.out.println(c.getCname()+" is eating.");
	}
	//sound method taking animal reference variable as parameter
	public void sound(Animal a){
		Cat c=(Cat)a;
		System.out.println(c.getCcolour()+" "+c.getCname()+" is meowing.");
	}
}
