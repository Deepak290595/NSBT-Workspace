package Inheritance;
import java.util.Scanner;
//Main class 
public class AnimalApp {
	//Execution start from here
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.println("Choose 1 for dog and 2 for cat");
		int n = sc.nextInt();
		//Switch
		switch(n){
		case 1: System.out.println("Enter Dog details: ");
			Animal a = new Dog();
			a.input(a);
			break;
		case 2: System.out.println();
			a = new Cat();
			a.input(a);
			break;
		
		}
	}
}
