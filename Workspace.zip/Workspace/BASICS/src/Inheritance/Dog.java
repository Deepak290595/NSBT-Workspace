package Inheritance;
import java.util.Scanner;
public class Dog extends Animal {
	private String dcolour; //string type
	private String dname;
	//getter method
	public String getDcolour() {
		return dcolour;
	}
	//setter method
	public void setDcolour(String dcolour) {
		this.dcolour = dcolour;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	//input method of dog class overriding animal input method
	public void input(){
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Name of Dog : ");
		setDname(sc.nextLine());		//taking dog name as input
		System.out.println("Enter Colour of Dog : ");
		setDcolour(sc.nextLine());		//taking dog colour as input
	}
	//eat method accessible anywhere taking animal reference variable as parameter
	public void eat(Animal a){
		Dog d = (Dog)a;
		System.out.println(d.getDname()+" is eating");
	}
	//sound method taking animal reference as parameter
	public void sound(Animal a){
		Dog d = (Dog)a;
		System.out.println(d.getDcolour()+" "+d.getDname()+" is barking");
	}
}
