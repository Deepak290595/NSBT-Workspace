package Equals;

public class Student{
	private int stdid;
	private String name;
	private String city;
	public int getStdid() {
		return stdid;
	}
	public void setStdid(int stdid) {
		this.stdid = stdid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Student(int stdid, String name, String city) {
		this.stdid = stdid;
		this.name = name;
		this.city = city;
	}
	public static void main(String[] args) {
		Student s1 = new Student(10,"abc","delhi");
		Student s2 = new Student(10,"abc","delhi");
		System.out.println(s1.equals(s2));
	}
	public boolean equals(Student s){
		if(Student.this.name==Student.this.name)
			return true;
		else
			return false;
	}
}
