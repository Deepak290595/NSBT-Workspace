package methodcalling;

public class Main {
	static void x(int...a){
		System.out.println("VarArgs Method :" +a);
	}
	static void x(Integer a){
		System.out.println("Wrapping Method :" +a);
	}
	static void x(int a){
		System.out.println("Simple Method: " +a);
	}
	
	public static void main(String[] args) {
		x(10);
	}

}
