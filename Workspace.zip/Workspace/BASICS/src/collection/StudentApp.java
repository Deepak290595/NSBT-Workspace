package collection;

import java.util.Collections;
import java.util.Scanner;

public class StudentApp {
	
	public static void main(String[] args) {
		Student s = new Student();
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.println("Choose \n1.To use ArrayList\n2.To use LinkedList");
		int choice = sc.nextInt();
		if(choice==1){
			do{
				System.out.println("Enter\n1.To add details of student\n2.To delete a particular Student\n3.To display all students\n4.To display a particular student" +
						"\n5.To display data sorted on the basis of ID\n6.To display data sorted by Name\n7.To Exit");
				int n = sc.nextInt();
				switch(n){
					
				case 1:
					System.out.println("Enter the no. of students: ");
					int num = sc.nextInt();
					while(num>0){
					System.out.println("Enter student details\n1.Student ID: ");
					int iD=sc.nextInt();
					System.out.println("Enter student name: ");
					String name = sc.next();
					System.out.println("Enter student marks: ");
					int marks = sc.nextInt();
					s.arradd(new Student(iD,name,marks));
					num--;
					}
					break;
				case 2:
					System.out.println("Enter the ID of student you want to delete: ");
					int id =sc.nextInt();
					s.delarr(id);
					System.out.println("Student with ID "+id +" Deleted");
					break;
				case 3:
					System.out.println("Details: ");
					System.out.println(s.display(s.al));
					break;	
				case 4:
					System.out.println("Enter ID of student you want to display: ");
					System.out.println(s.disarr(sc.nextInt()));
					break;	
				case 5:
					System.out.println("Sorted Data");
					Collections.sort(s.al);
					System.out.println(s.getSortedStudent(s.al));
					break;
				case 6:
					System.out.println("Sorted Data");
					sortByName sn = new sortByName();
					Collections.sort(s.al, sn);
					System.out.println(s.getSortedStudent(s.al));
					break;
				case 7:
					sc.close();
					System.exit(5);
					break;
				default:
					System.out.println("Wrong Choice!!\nChoose Again");
					break;
				}
			}while(true);
			
		}else if(choice==2){
			do{
				System.out.println("Enter\n1.To add details of student\n2.To delete a particular Student\n3.To display all students\n4.To display a particular student" +
						"\n5.To display data sorted on the basis of ID\n6.To display data sorted by Name\n7.To Exit");
				int n = sc.nextInt();
				switch(n){
					
				case 1:
					System.out.println("Enter student details\n1.Student ID: ");
					int iD=sc.nextInt();
					System.out.println("Enter student name: ");
					String name = sc.next();
					System.out.println("Enter student marks: ");
					int marks = sc.nextInt();
					s.linkadd(new Student(iD,name,marks));
					break;
				case 2:
					System.out.println("Enter the ID of student you want to delete: ");
					int id=sc.nextInt();
					s.dellink(id);
					System.out.println("Student with ID "+ id +" Deleted");
					break;
				case 3:
					System.out.println("Details: ");
					System.out.println(s.display(s.ll));
					break;	
				case 4:
					System.out.println("Enter ID of student you want to display: ");
					System.out.println(s.dislink(sc.nextInt()));
					break;
				case 5:
					System.out.println("Sorted Data");
					Collections.sort(s.ll);
					System.out.println(s.getSortedStudent(s.ll));
					break;
				case 6:
					System.out.println("Sorted Data");
					sortByName sn = new sortByName();
					Collections.sort(s.ll, sn);
					System.out.println(s.getSortedStudent(s.al));
					break;
				case 7:
					sc.close();
					System.exit(5);
					break;
				default:
					System.out.println("Wrong Choice!!\nChoose Again");
					break;
				}
			}while(true);
		}
	}
}
