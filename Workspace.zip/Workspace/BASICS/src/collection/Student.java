package collection;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Student implements Comparable<Student> {
	private int sID;
	private String sName;
	private int sMarks;
	public int getsID() {
		return sID;
	}
	public void setsID(int sID) {
		this.sID = sID;
	}
	public String getsName() {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	public int getsMarks() {
		return sMarks;
	}
	public void setsMarks(int sMarks) {
		this.sMarks = sMarks;
	}

	public Student() {
		this(0,"null",0);
	}
	public Student(int sID, String sName, int sMarks) {
		this.sID = sID;
		this.sName = sName;
		this.sMarks = sMarks;
	}
	public String toString(){
		return "Student ID: "+sID+"\nStudent Name: "+sName+"\nStudent Marks: "+sMarks;
	}
	
	List<Student> al= new ArrayList<Student>();
	List<Student> ll= new LinkedList<Student>();
	
	public List<Student> display(List<Student> l){
			return l;
	}
	public Student dislink(int id){
		for(int i=0;i<ll.size();i++){
			if(ll.get(i).getsID()==id)
					return ll.get(i);
	}
		return null;
	}
	public Student disarr(int id){
		for(int i=0;i<al.size();i++){
			if(al.get(i).getsID()==id)
					return al.get(i);
	}
		return null;
		
	}
	public void linkadd(Student s){
		
		ll.add(s);
	}
	public void arradd(Student s){
		al.add(s);
	}
	public void delarr(int id){
		for(int i=0;i<al.size();i++){
			if(al.get(i).getsID()==id)
				al.remove(i);
		}
	}
	public void dellink(int id){
		for(int i=0;i<ll.size();i++){
			if(ll.get(i).getsID()==id)
				ll.remove(i);
		}
	}
	public List<Student> getSortedStudent(List<Student> l){
		return l;	
	}
	@Override
	public int compareTo(Student s) {
		if(this.sID==s.sID)  
			return 0;  
			else if(this.sID>s.sID)  
			return 1;  
			else  
			return -1;  
	}
}
