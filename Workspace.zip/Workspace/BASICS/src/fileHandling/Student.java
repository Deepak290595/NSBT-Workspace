package fileHandling;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;


public class Student {
	private int sID;
	private String sName;
	private String sCity;
	private long phoneNo;
	public int getsID() {
		return sID;
	}
	public void setsID(int sID) {
		this.sID = sID;
	}
	public String getsName() {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	public String getsCity() {
		return sCity;
	}
	public void setsCity(String sCity) {
		this.sCity = sCity;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	
	public Student(int sID, String sName, String sCity, long phoneNo) {
		this.sID = sID;
		this.sName = sName;
		this.sCity = sCity;
		this.phoneNo = phoneNo;
	}
	public Student() {
		// TODO Auto-generated constructor stub
	}
	public String toString(){
		return sID+" "+sName+" "+sCity+" "+phoneNo;
		
	}
	List<Student> al= new ArrayList<Student>();
	FileReader fileReader;
	FileWriter fileWriter=null;
	public void writeToFile(Student student){
		try {
			fileWriter = new FileWriter("C:/Users/temp/Desktop/Test/Student.txt",true);
			PrintWriter printWriter = new PrintWriter(fileWriter);
			printWriter.format("%s\n", student);
			printWriter.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally{
			try {
				fileWriter.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void readFromFile(){
		try {
			fileReader = new FileReader("C:/Users/temp/Desktop/Test/Student.txt");
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			String string = bufferedReader.readLine();
			while(string!=null){
				String [] arrOfStr = string.split(" ");
				int id = Integer.parseInt(arrOfStr[0]);
				String name = arrOfStr[1];
				String city = arrOfStr[2];
				long num =Long.parseLong(arrOfStr[3]);
				Student student = new Student(id, name, city, num);
				al.add(student);
				string = bufferedReader.readLine();
				
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		finally{
			try {
				fileReader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	public List<Student> display(List<Student> l){
		return l;
}
	/*public void arradd(Student student){
		al.add(student);
	}*/
}
