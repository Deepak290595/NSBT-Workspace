package fileHandling;

import java.util.Scanner;

public class StudentFile {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Student student = new Student();
		do{
			
		System.out.println("Choose\n1.To write student data to file\n2.To display student data\n3.Exit");
		int n = scanner.nextInt();
			switch(n){
			case 1:
				System.out.print("Enter the number of students: ");
				int num = scanner.nextInt();
				while(num>0){
					System.out.println("Enter ID: ");
					int iD = scanner.nextInt();					
					System.out.println("Enter name: ");
					String name = scanner.next();
					System.out.println("Enter City: ");
					String city = scanner.next();
					System.out.println("Enter phone number: ");
					long pNum = scanner.nextLong();
					student.writeToFile(new Student(iD,name,city,pNum));
					num--;
					}
					break;
			case 2:
				student.readFromFile();
				System.out.println("Student Details: ");
				System.out.println(student.display(student.al));
				break;
			case 3:
				scanner.close();
				System.exit(3);
				break;
			default:
				System.out.println("Choose correct option");
				break;
				}
			
				
			}while(true);
	}

}
