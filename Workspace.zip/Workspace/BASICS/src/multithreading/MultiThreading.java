package multithreading;

class ChildThread implements Runnable{

	@Override
	public void run() {
		for(int i = 1;i<=5;i++){
			System.out.println("Child Thread: "+i);
	}
	
}
}
class ChildThread1 implements Runnable{

	@Override
	public void run() {
		for(int i = 1;i<=5;i++){
			System.out.println("Child Thread: "+i);
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
}
public class MultiThreading {
	public static void main(String[] args) {
		Thread.currentThread().setPriority(2);
		ChildThread childThread = new ChildThread();
		ChildThread1 childThread1 = new ChildThread1();
		Thread thread1 = new Thread(childThread);
		Thread thread2 = new Thread(childThread1);
		thread2.setDaemon(true);
		thread1.start();
		thread2.start();
		System.out.println(thread1.getName()+" "+thread1.getPriority());
		for(int i =0; i<=5;i++){
			System.out.println("Main Thread: "+i);
		}
	}
	
}
