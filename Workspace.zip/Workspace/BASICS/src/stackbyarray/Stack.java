package stackbyarray;

public class Stack {
	private int maxsize;
	private int[] stackArr;
	private int top;
	 Stack(int s){
		 maxsize=s;
		 stackArr = new int[maxsize];
		 top=-1;
	}
	public void push(int j){
		stackArr[++top]=j;
	}
	public int pop(){
		return stackArr[top--];
	}
	public int peek(){
		return stackArr[top];
	}
	public boolean isEmpty(){
		return (top==-1);
	}
	public boolean isFull(){
		return (top==maxsize-1);
	}
	public static void main(String[] args) {
		Stack s = new Stack(5);
		s.push(1);
		s.push(2);
		s.push(3);
		s.push(4);
		s.peek();
		while(!s.isEmpty()){
			int value = s.pop();
			System.out.print(value+ " ");
		}
		
		
	}

}
