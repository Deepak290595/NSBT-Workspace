package abstraction;

public interface DigitalDevice extends Device {
	void DisplayScreen();
}
class Computer implements DigitalDevice{

	@Override
	public void displayBrightness() {
		System.out.println("Computer.... Brightness");
	}

	@Override
	public void displayDetails() {	
		System.out.println("Computer Details");
	}

	@Override
	public void DisplayScreen() {
		System.out.println("Computer Has Display screen");
	}

	@Override
	public void run() {
		System.out.println("Computer running successfully");
		
	}
	
}
class Television implements DigitalDevice{

	@Override
	public void displayBrightness() {
		System.out.println("Television....Brightness");
	}

	@Override
	public void displayDetails() {
			System.out.println("Television....Details");
	}

	@Override
	public void DisplayScreen() {
		System.out.println("Television has DisplayScreen");
	}

	@Override
	public void run() {
		System.out.println("Television running successfully");
	}
	
}
