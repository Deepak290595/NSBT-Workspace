package abstraction;



public class Main {
	public static void main(String[] args) {
		Device d1 = new Computer();
		Device d2 = new Television();
		Device d3 = new Fan();
		d3.run();
		d2.run();
		d1.run();
		d1.displayBrightness();
	}

}
