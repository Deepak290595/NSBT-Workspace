package abstraction;

abstract class ElectronicDevice implements Device {
	public abstract void run();
	public void displayDetails(){}
}
class Fan extends ElectronicDevice{

/*@Override
	public void displayBrightness() {
		// TODO Auto-generated method stub
		
	}*/

	@Override
	public void displayDetails() {
		System.out.println("Fan...Details");
	}

	@Override
	public void run() {
		
		System.out.println("Fan is running successfully");
	}

	@Override
	public void displayBrightness() {
		// TODO Auto-generated method stub
		
	}
	
}
