package abstraction;

public interface Device {
	void displayBrightness();
	void displayDetails();
	void run();
}