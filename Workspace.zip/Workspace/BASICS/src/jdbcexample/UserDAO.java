package jdbcexample;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDAO {
	Connections connections=new Connections();
	PreparedStatement preparedStatement;
	
	public void signUp(User user){
		Connection connection = connections.createConnection();
		try {
			preparedStatement = connection.prepareStatement("insert into testusers values(?,?,?,?)");
			preparedStatement.setString(1,user.getuID());
			preparedStatement.setString(2,user.getuName());
			preparedStatement.setString(3,user.getuMail());
			preparedStatement.setString(4,user.getuPassword());
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				connection.close();
				preparedStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public boolean signIn(String id,String password){
		Connection connection = connections.createConnection();
		try {
			preparedStatement = connection.prepareStatement("select id,password from testusers where id=? and password=? ");
			preparedStatement.setString(1,id);
			preparedStatement.setString(2, password);
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next()) {
			String pwc = rs.getString("password");
			String idc = rs.getString("id");
			if(pwc.equals(password)&&idc.equalsIgnoreCase(id)){
				System.out.println("Successfull");
				return true;
			}
			//System.exit(0);
			/*else if(user.equals(password)){
				System.out.println("Invalid");
			}*/
			 }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				connection.close();
				preparedStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return false;
		
	}
	public void update(String id,String password){
		Connection connection = connections.createConnection();
		try {
			preparedStatement = connection.prepareStatement("update testusers set password=? where id=?");
			preparedStatement.setString(1, password);
			preparedStatement.setString(2, id);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				connection.close();
				preparedStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
	
	public void delete(String id){
		Connection connection = connections.createConnection();
		try {
			preparedStatement = connection.prepareStatement("delete from testusers where id = ?");
			preparedStatement.setString(1, id);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				connection.close();
				preparedStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
