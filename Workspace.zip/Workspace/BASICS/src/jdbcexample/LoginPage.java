package jdbcexample;

import java.util.Scanner;


public class LoginPage {
	public static void main(String[] args) {	
	@SuppressWarnings("resource")
	Scanner scanner = new Scanner(System.in);
	//Connections connections=new Connections();
	UserDAO userDAO = new UserDAO();
	//connections.createConnection();
	do{	
		System.out.println("Enter choice: \n1.Sign Up\n2.Sign In");
		int choice = scanner.nextInt();
		switch(choice){
		case 1:
			System.out.println("Enter Used ID: ");
			String id = scanner.next();
			System.out.println("Enter Name: ");
			String name = scanner.next();
			System.out.println("Enter Password: ");
			String password = scanner.next();
			System.out.println("Enter Mail: ");
			String mail = scanner.next();
			userDAO.signUp(new User(id, name, password, mail));
			System.out.println("Sign up successful...");
			break;
		case 2:
			System.out.println("Enter User ID: ");
			String id1 = scanner.next();
			System.out.println("Enter Password: ");
			String password1 = scanner.next();
//			userDAO.signIn(id1,password1);
			if(userDAO.signIn(id1,password1))
			{
			System.out.println("Choose: \n1.Change Password: \n2.Delete Account: ");
			int n = scanner.nextInt();
			if(n==1){
				System.out.println("Enter new password: ");
				String newpassword = scanner.next();
				userDAO.update(id1, newpassword);
			}
			else if(n==2){
				userDAO.delete(id1);
			}
			}
			else{
				System.out.println("Wrong Credentials");
			}
			break;
		}
	}while(true);
}
}
