package jdbcexample;

public class User {
	private String uID;
	private String uName;
	private String uPassword;
	private String uMail;
	
	public String getuID() {
		return uID;
	}

	public void setuID(String uID) {
		this.uID = uID;
	}

	public String getuName() {
		return uName;
	}

	public void setuName(String uName) {
		this.uName = uName;
	}

	public String getuPassword() {
		return uPassword;
	}

	public void setuPassword(String uPassword) {
		this.uPassword = uPassword;
	}

	public String getuMail() {
		return uMail;
	}

	public void setuMail(String uMail) {
		this.uMail = uMail;
	}
	
	public User(String uID, String uName, String uPassword, String uMail) {
		this.uID = uID;
		this.uName = uName;
		this.uPassword = uPassword;
		this.uMail = uMail;
	}

	@Override
	public String toString() {
		return  uID  + uName + uPassword + uMail ;
	}
}
