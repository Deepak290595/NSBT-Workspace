package Hello;

public class Intro {
	public void display(){
		System.out.println("Welcome!!!");
	}
}
	