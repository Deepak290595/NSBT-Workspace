package Hello;

class Employee
{
	int empid;
	String ename;
	float salary;
	public Employee(int empid,String ename,float salary)
	{
		this.empid=empid;
		this.ename=ename;
		this.salary=salary;
	}
	public void displayEmpDetails()
	{
		System.out.println(empid+" "+ename+" "+salary);
	}
}

public class CallByReferenceDemo {

	public void displaySalarySlip(Employee emp)
	{
		emp.displayEmpDetails();
		emp=new Employee(2,"emp1",7878);
		emp.ename="employee2";
		emp.displayEmpDetails();
	}
	
	public static void main(String[] args) 
	{
		
		Employee e1=new Employee(1,"emp1",7878);
		CallByReferenceDemo c1=new CallByReferenceDemo();		
		c1.displaySalarySlip(e1);
		e1.displayEmpDetails();

	}

}
