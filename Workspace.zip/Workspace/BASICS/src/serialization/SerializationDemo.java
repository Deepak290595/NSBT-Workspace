package serialization;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerializationDemo{
	
	public void displayBook(){
		FileInputStream fileInputStream;
		try {
			fileInputStream = new FileInputStream("BookDetails");
			@SuppressWarnings("resource")
			ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
			Book book2 = (Book)objectInputStream.readObject();
			System.out.println(book2.getBookID() +" "+book2.getBookName()+" "+book2.getPublisher());
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
	public void saveBook(Book book){
		FileOutputStream fileOutputStream;
		try {
			fileOutputStream = new FileOutputStream("BookDetails");
			@SuppressWarnings("resource")
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(book);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args) {
		SerializationDemo demo = new SerializationDemo();
		Book book = new Book();
		book.setBookID(100);
		book.setBookName("Java");
		book.setPublisher("oracle");
		demo.saveBook(book);
		demo.displayBook();
		
		
	}
}
