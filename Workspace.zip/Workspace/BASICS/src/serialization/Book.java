package serialization;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Book implements Serializable,Cloneable{
	private int bookID;
	private String bookName;
	private transient String publisher;
	public int getBookID() {
		return bookID;
	}
	public void setBookID(int bookID) {
		this.bookID = bookID;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	
	
}
