package com.nucleus.objmethods;


class CabDriver implements Runnable{

	@Override
	public void run() {		
		System.out.println("Cab Driver driving");
	}
	
}
class CabRider implements Runnable{

	@Override
	public void run() {
		
	}
	
}
public class CabRide {
	public static void main(String[] args) {
		CabDriver cabDriver = new CabDriver();
		Thread driverThread = new Thread(cabDriver);
		driverThread.setName("driverThread");
		CabRider cabRider1 = new CabRider();
		Thread riderThread1 = new Thread(cabRider1);
		riderThread1.setName("riderThread1");
		CabRider cabRider2 = new CabRider();
		Thread riderThread2 = new Thread(cabRider2);
		riderThread2.setName("riderThread2");
		if(riderThread1.isAlive()||riderThread2.isAlive()){
			
		}
		else if(driverThread.isAlive())
			driverThread.notifyAll();
	}
}
