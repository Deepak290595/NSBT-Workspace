package com.nucleus.multithreading;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class ConsoleLevel implements Runnable {
	Scanner scanner;
	FileLevel fileLevel;
	FileReader fileReader;
	FileWriter fileWriter;
	FileWrite fileWrite;
/*	public Student readConsole(){
		scanner = new Scanner(System.in);
		System.out.print("Enter no . of students: ");
		int n = scanner.nextInt();
		while(n>0){
		System.out.print("Enter Student ID: ");
		int iD = scanner.nextInt();
		System.out.print("Enter Student Name: ");
		String name = scanner.next();
		System.out.print("Enter City: ");
		String city = scanner.next();
		System.out.print("Enter Phone number: ");
		long num = scanner.nextLong();
		student = new Student(iD, name, city, num);
		fileLevel.writeFile(student);
		n--;
		}
		System.out.println(student);
		return student;	
	}*/
	public void readFile(){
		try {
			fileReader = new FileReader("C:/Users/temp/Desktop/Test/Sync/Student2.txt");
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			String string = bufferedReader.readLine();
			while(string!=null){
				String [] arrOfStr = string.split(" ");
				int id = Integer.parseInt(arrOfStr[0]);
				String name = arrOfStr[1];
				String city = arrOfStr[2];
				long num =Long.parseLong(arrOfStr[3]);
				Student student2 = new Student(id, name, city, num);
				System.out.println("File 2: " +student2);
				fileWrite.writeFile(student2);
				string = bufferedReader.readLine();
				
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
		e.printStackTrace();
	}
		finally{
			try {
				fileReader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	/*public void writeFile(Student student){
		try {
			System.out.println("Writemethod: " +student);
			fileWriter = new FileWriter("C:/Users/temp/Desktop/Test/Sync/Test1.txt",true);
			PrintWriter printWriter = new PrintWriter(fileWriter);
			printWriter.format("%s\n", student);
			printWriter.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally{
			try {
				fileWriter.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}*/
	@Override
	public void run() {
		readFile();
		//fileWrite.writeFile(student);
		//System.out.println("Console run "+student1);
		
	}
}
