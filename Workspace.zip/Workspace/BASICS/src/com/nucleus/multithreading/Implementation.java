package com.nucleus.multithreading;

public class Implementation {
	public static void main(String[] args) {
		FileLevel fileLevel = new FileLevel();
		Thread thread1 = new Thread(fileLevel);
		ConsoleLevel consoleLevel = new ConsoleLevel();
		Thread thread2 = new Thread(consoleLevel);
		thread1.start();
		thread2.start();
	}
	
}
