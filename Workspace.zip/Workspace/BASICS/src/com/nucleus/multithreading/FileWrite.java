package com.nucleus.multithreading;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class FileWrite {
	FileWriter fileWriter;
	public void writeFile(Student student3){
		try {
			System.out.println("Writemethod: " +student3);
			fileWriter = new FileWriter("C:/Users/temp/Desktop/Test/Sync/Test.txt",true);
			PrintWriter printWriter = new PrintWriter(fileWriter);
			printWriter.format("%s\n", student3);
			printWriter.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
		/*finally{
			try {
				fileWriter.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}*/
	}
}
