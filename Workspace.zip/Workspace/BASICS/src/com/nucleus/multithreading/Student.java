package com.nucleus.multithreading;

public class Student {
	private int sID;
	private String sName;
	private String sCity;
	private long phoneNo;
	public int getsID() {
		return sID;
	}
	public void setsID(int sID) {
		this.sID = sID;
	}
	public String getsName() {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	public String getsCity() {
		return sCity;
	}
	public void setsCity(String sCity) {
		this.sCity = sCity;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	
	public Student(int sID, String sName, String sCity, long phoneNo) {
		this.sID = sID;
		this.sName = sName;
		this.sCity = sCity;
		this.phoneNo = phoneNo;
	}

	public String toString(){
		return sID+" "+sName+" "+sCity+" "+phoneNo;
		
	}
}