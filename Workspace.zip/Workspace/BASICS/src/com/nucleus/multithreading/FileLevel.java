package com.nucleus.multithreading;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileLevel implements Runnable {
	FileReader fileReader;
	FileWriter fileWriter;
	FileWrite fileWrite;
	public void readFile(){
		try {
			fileReader = new FileReader("C:/Users/temp/Desktop/Test/Sync/Student1.txt");
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			String string = bufferedReader.readLine();
			while(string!=null){
				String [] arrOfStr = string.split(" ");
				int id = Integer.parseInt(arrOfStr[0]);
				String name = arrOfStr[1];
				String city = arrOfStr[2];
				long num =Long.parseLong(arrOfStr[3]);
				Student student1 = new Student(id, name, city, num);
				System.out.println("File 1: " +student1);
				fileWrite.writeFile(student1);
				string = bufferedReader.readLine();
				
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
		e.printStackTrace();
	}
		finally{
			try {
				fileReader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
/*	public void writeFile(Student student){
			try {
				System.out.println("Writemethod: " +student);
				fileWriter = new FileWriter("C:/Users/temp/Desktop/Test/Sync/Test1.txt",true);
				PrintWriter printWriter = new PrintWriter(fileWriter);
				printWriter.format("%s\n", student);
				printWriter.flush();
			} catch (IOException e) {
				e.printStackTrace();
			}
			finally{
				try {
					fileWriter.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}*/
	@Override
	public void run() {
		readFile();
	}
}
