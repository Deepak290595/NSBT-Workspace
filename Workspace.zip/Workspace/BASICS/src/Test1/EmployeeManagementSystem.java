package Test1;

import Hello.Intro;

//Parent Class
class Employee{
	//static integer EmpID
	static int EmpID;
	//String type
	String EmpName;
	//Double type accessed within same class
	private double Salary;
	//constructor with 2 arguments accessed within same class
	private Employee(int EmpID,String EmpName){
		Employee.EmpID = EmpID;
		this.EmpName = EmpName;
	}
	//Constructor with three arguments accessed by child class within same package or different package
	protected Employee(int EmpID,String EmpName,double Salary){
		Employee.EmpID = EmpID;
		this.EmpName = EmpName;
		this.Salary = Salary;
	}
	//Single parametrised constructor within same package
	Employee(int Empid){
	//Calls constructor with two arguments
		this(10,"abc");
	}
	//non parametrised Constructor
	Employee(){
	//Calls constructor with single argument
		this(07);
	}
	//Method display to display values
	public void display(Employee E){
		System.out.println("Employee ID : "+EmpID); // Print ID
		System.out.println("Employee Name : "+EmpName);// Print Name
		System.out.println("Employee Salary : "+Salary);// Print Salary
	}
	
}
//SubClass extending Employee Class accessible anywhere
public class EmployeeManagementSystem extends Employee{
	public static void main(String[] args) {
		Employee E1 = new Employee();
		Intro I = new Intro();
		I.display();
		E1.display(E1);
	}

}
