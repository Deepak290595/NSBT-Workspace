package Test1;

public class Manager extends Employee {

	public static void main(String[] args) {
		Employee E2 = new Employee(30,"QWERTY",100);
		E2.display(E2);
		//Employee E3 = new Employee(10,"New");	
	}
	/*protected double anSalary(double Salary){
		double ansalary = 12*Salary;
		return ansalary;
	}*/

}
